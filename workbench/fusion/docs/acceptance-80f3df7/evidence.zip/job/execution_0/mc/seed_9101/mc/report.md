# Monte Carlo SRAM hold_snm evaluation

- Circuit: 1×1 6T SRAM, target cell [0, 0], OpenYield V2.2.6
- Conditions: TT, 1 V, 27 °C
- Sampling: numpy_independent_positive_u0
- Relative process spread: 5.00%
- Measured hold_snm. Failure threshold: value < 327.65 mV
- Seed: 9101
- Revision: 80f3df7ff83d2c8e7eae751ed10d5111d485ab1f
- Requested: 4 / 4
- Classified: 4
- Margin failures: 0
- Unclassified: 0

Estimated failure fraction: **0.0000%** (0/4).
95% Wilson interval: 0.0000%–48.9891%.
For this case the result applies to the selected cell and hold_snm operation.
