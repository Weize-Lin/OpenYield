# Monte Carlo SRAM read evaluation

- Circuit: 3×2 6T SRAM, target cell [1, 1], OpenYield V2.2.6
- Conditions: TT, 1 V, 27 °C
- Sampling: numpy_independent_positive_u0
- Relative process spread: 5.00%
- Measured TREAD_TOTAL. Failure threshold: value > 1 ns
- Seed: 2
- Revision: 80f3df7ff83d2c8e7eae751ed10d5111d485ab1f
- Requested: 4 / 4
- Classified: 4
- Read functional failures: 0
- Timing failures: 0
- Unclassified: 0

Estimated failure fraction: **0.0000%** (0/4).
95% Wilson interval: 0.0000%–48.9891%.
For this case the result applies to the selected cell and read operation.
