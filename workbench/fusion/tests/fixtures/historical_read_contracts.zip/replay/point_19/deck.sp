.title SRAM_6T_CORE_3x2_MC_TB
.include /home/shammy/projects/OpenYield-oct01/outputs/read_replay_2_a0ad789_20261123/inputs/models_TT.spice
.include /home/shammy/projects/OpenYield-oct01/outputs/read_replay_2_a0ad789_20261123/inputs/point_19/mc_read_table.data
.TRAN 1.0000e-11 1.9000e-08
.OPTIONS MEASURE MEASFAIL=1
.STEP data=table
.param vth0_NMOS_VTG_PGL_0_0=0.0
.param u0_NMOS_VTG_PGL_0_0=0.0
.param voff_NMOS_VTG_PGL_0_0=0.0
.param vth0_NMOS_VTG_PGR_0_0=0.0
.param u0_NMOS_VTG_PGR_0_0=0.0
.param voff_NMOS_VTG_PGR_0_0=0.0
.param vth0_NMOS_VTG_PDL_0_0=0.0
.param u0_NMOS_VTG_PDL_0_0=0.0
.param voff_NMOS_VTG_PDL_0_0=0.0
.param vth0_PMOS_VTG_PUL_0_0=0.0
.param u0_PMOS_VTG_PUL_0_0=0.0
.param voff_PMOS_VTG_PUL_0_0=0.0
.param vth0_NMOS_VTG_PDR_0_0=0.0
.param u0_NMOS_VTG_PDR_0_0=0.0
.param voff_NMOS_VTG_PDR_0_0=0.0
.param vth0_PMOS_VTG_PUR_0_0=0.0
.param u0_PMOS_VTG_PUR_0_0=0.0
.param voff_PMOS_VTG_PUR_0_0=0.0
.param vth0_NMOS_VTG_PGL_0_1=0.0
.param u0_NMOS_VTG_PGL_0_1=0.0
.param voff_NMOS_VTG_PGL_0_1=0.0
.param vth0_NMOS_VTG_PGR_0_1=0.0
.param u0_NMOS_VTG_PGR_0_1=0.0
.param voff_NMOS_VTG_PGR_0_1=0.0
.param vth0_NMOS_VTG_PDL_0_1=0.0
.param u0_NMOS_VTG_PDL_0_1=0.0
.param voff_NMOS_VTG_PDL_0_1=0.0
.param vth0_PMOS_VTG_PUL_0_1=0.0
.param u0_PMOS_VTG_PUL_0_1=0.0
.param voff_PMOS_VTG_PUL_0_1=0.0
.param vth0_NMOS_VTG_PDR_0_1=0.0
.param u0_NMOS_VTG_PDR_0_1=0.0
.param voff_NMOS_VTG_PDR_0_1=0.0
.param vth0_PMOS_VTG_PUR_0_1=0.0
.param u0_PMOS_VTG_PUR_0_1=0.0
.param voff_PMOS_VTG_PUR_0_1=0.0
.param vth0_NMOS_VTG_PGL_1_0=0.0
.param u0_NMOS_VTG_PGL_1_0=0.0
.param voff_NMOS_VTG_PGL_1_0=0.0
.param vth0_NMOS_VTG_PGR_1_0=0.0
.param u0_NMOS_VTG_PGR_1_0=0.0
.param voff_NMOS_VTG_PGR_1_0=0.0
.param vth0_NMOS_VTG_PDL_1_0=0.0
.param u0_NMOS_VTG_PDL_1_0=0.0
.param voff_NMOS_VTG_PDL_1_0=0.0
.param vth0_PMOS_VTG_PUL_1_0=0.0
.param u0_PMOS_VTG_PUL_1_0=0.0
.param voff_PMOS_VTG_PUL_1_0=0.0
.param vth0_NMOS_VTG_PDR_1_0=0.0
.param u0_NMOS_VTG_PDR_1_0=0.0
.param voff_NMOS_VTG_PDR_1_0=0.0
.param vth0_PMOS_VTG_PUR_1_0=0.0
.param u0_PMOS_VTG_PUR_1_0=0.0
.param voff_PMOS_VTG_PUR_1_0=0.0
.param vth0_NMOS_VTG_PGL_1_1=0.0
.param u0_NMOS_VTG_PGL_1_1=0.0
.param voff_NMOS_VTG_PGL_1_1=0.0
.param vth0_NMOS_VTG_PGR_1_1=0.0
.param u0_NMOS_VTG_PGR_1_1=0.0
.param voff_NMOS_VTG_PGR_1_1=0.0
.param vth0_NMOS_VTG_PDL_1_1=0.0
.param u0_NMOS_VTG_PDL_1_1=0.0
.param voff_NMOS_VTG_PDL_1_1=0.0
.param vth0_PMOS_VTG_PUL_1_1=0.0
.param u0_PMOS_VTG_PUL_1_1=0.0
.param voff_PMOS_VTG_PUL_1_1=0.0
.param vth0_NMOS_VTG_PDR_1_1=0.0
.param u0_NMOS_VTG_PDR_1_1=0.0
.param voff_NMOS_VTG_PDR_1_1=0.0
.param vth0_PMOS_VTG_PUR_1_1=0.0
.param u0_PMOS_VTG_PUR_1_1=0.0
.param voff_PMOS_VTG_PUR_1_1=0.0
.param vth0_NMOS_VTG_PGL_2_0=0.0
.param u0_NMOS_VTG_PGL_2_0=0.0
.param voff_NMOS_VTG_PGL_2_0=0.0
.param vth0_NMOS_VTG_PGR_2_0=0.0
.param u0_NMOS_VTG_PGR_2_0=0.0
.param voff_NMOS_VTG_PGR_2_0=0.0
.param vth0_NMOS_VTG_PDL_2_0=0.0
.param u0_NMOS_VTG_PDL_2_0=0.0
.param voff_NMOS_VTG_PDL_2_0=0.0
.param vth0_PMOS_VTG_PUL_2_0=0.0
.param u0_PMOS_VTG_PUL_2_0=0.0
.param voff_PMOS_VTG_PUL_2_0=0.0
.param vth0_NMOS_VTG_PDR_2_0=0.0
.param u0_NMOS_VTG_PDR_2_0=0.0
.param voff_NMOS_VTG_PDR_2_0=0.0
.param vth0_PMOS_VTG_PUR_2_0=0.0
.param u0_PMOS_VTG_PUR_2_0=0.0
.param voff_PMOS_VTG_PUR_2_0=0.0
.param vth0_NMOS_VTG_PGL_2_1=0.0
.param u0_NMOS_VTG_PGL_2_1=0.0
.param voff_NMOS_VTG_PGL_2_1=0.0
.param vth0_NMOS_VTG_PGR_2_1=0.0
.param u0_NMOS_VTG_PGR_2_1=0.0
.param voff_NMOS_VTG_PGR_2_1=0.0
.param vth0_NMOS_VTG_PDL_2_1=0.0
.param u0_NMOS_VTG_PDL_2_1=0.0
.param voff_NMOS_VTG_PDL_2_1=0.0
.param vth0_PMOS_VTG_PUL_2_1=0.0
.param u0_PMOS_VTG_PUL_2_1=0.0
.param voff_PMOS_VTG_PUL_2_1=0.0
.param vth0_NMOS_VTG_PDR_2_1=0.0
.param u0_NMOS_VTG_PDR_2_1=0.0
.param voff_NMOS_VTG_PDR_2_1=0.0
.param vth0_PMOS_VTG_PUR_2_1=0.0
.param u0_PMOS_VTG_PUR_2_1=0.0
.param voff_PMOS_VTG_PUR_2_1=0.0
.subckt SRAM_6T_CORE_3x2 VDD VSS BL0 BL1 BLB0 BLB1 WL0 WL1 WL2
.subckt SRAM_6T_CELL_0_0 VDD VSS BL BLB WL
.model NMOS_VTG_PGL_0_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGL_0_0' k1=0.4 u0='u0_NMOS_VTG_PGL_0_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGL_0_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PGR_0_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGR_0_0' k1=0.4 u0='u0_NMOS_VTG_PGR_0_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGR_0_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDL_0_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDL_0_0' k1=0.4 u0='u0_NMOS_VTG_PDL_0_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDL_0_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDR_0_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDR_0_0' k1=0.4 u0='u0_NMOS_VTG_PDR_0_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDR_0_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model PMOS_VTG_PUL_0_0 pmos level=54 vth0='vth0_PMOS_VTG_PUL_0_0' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUL_0_0' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUL_0_0' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
.model PMOS_VTG_PUR_0_0 pmos level=54 vth0='vth0_PMOS_VTG_PUR_0_0' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUR_0_0' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUR_0_0' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
RR_Q_0 Q Q_end 100.0Ohm
CCg_Q_0 Q_end 0 0.001pF
RR_QB_0 QB QB_end 100.0Ohm
CCg_QB_0 QB_end 0 0.001pF
MPGL BL WL Q_end VSS NMOS_VTG_PGL_0_0 l=5e-08 w=1.35e-07
MPGR BLB WL QB_end VSS NMOS_VTG_PGR_0_0 l=5e-08 w=1.35e-07
MPDL Q_end QB VSS VSS NMOS_VTG_PDL_0_0 l=5e-08 w=2.05e-07
MPDR QB_end Q VSS VSS NMOS_VTG_PDR_0_0 l=5e-08 w=2.05e-07
MPUL Q_end QB VDD VDD PMOS_VTG_PUL_0_0 l=5e-08 w=9e-08
MPUR QB_end Q VDD VDD PMOS_VTG_PUR_0_0 l=5e-08 w=9e-08
.ends SRAM_6T_CELL_0_0

.subckt SRAM_6T_CELL_0_1 VDD VSS BL BLB WL
.model NMOS_VTG_PGL_0_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGL_0_1' k1=0.4 u0='u0_NMOS_VTG_PGL_0_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGL_0_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PGR_0_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGR_0_1' k1=0.4 u0='u0_NMOS_VTG_PGR_0_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGR_0_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDL_0_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDL_0_1' k1=0.4 u0='u0_NMOS_VTG_PDL_0_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDL_0_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDR_0_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDR_0_1' k1=0.4 u0='u0_NMOS_VTG_PDR_0_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDR_0_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model PMOS_VTG_PUL_0_1 pmos level=54 vth0='vth0_PMOS_VTG_PUL_0_1' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUL_0_1' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUL_0_1' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
.model PMOS_VTG_PUR_0_1 pmos level=54 vth0='vth0_PMOS_VTG_PUR_0_1' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUR_0_1' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUR_0_1' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
RR_Q_0 Q Q_end 100.0Ohm
CCg_Q_0 Q_end 0 0.001pF
RR_QB_0 QB QB_end 100.0Ohm
CCg_QB_0 QB_end 0 0.001pF
MPGL BL WL Q_end VSS NMOS_VTG_PGL_0_1 l=5e-08 w=1.35e-07
MPGR BLB WL QB_end VSS NMOS_VTG_PGR_0_1 l=5e-08 w=1.35e-07
MPDL Q_end QB VSS VSS NMOS_VTG_PDL_0_1 l=5e-08 w=2.05e-07
MPDR QB_end Q VSS VSS NMOS_VTG_PDR_0_1 l=5e-08 w=2.05e-07
MPUL Q_end QB VDD VDD PMOS_VTG_PUL_0_1 l=5e-08 w=9e-08
MPUR QB_end Q VDD VDD PMOS_VTG_PUR_0_1 l=5e-08 w=9e-08
.ends SRAM_6T_CELL_0_1

.subckt SRAM_6T_CELL_1_0 VDD VSS BL BLB WL
.model NMOS_VTG_PGL_1_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGL_1_0' k1=0.4 u0='u0_NMOS_VTG_PGL_1_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGL_1_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PGR_1_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGR_1_0' k1=0.4 u0='u0_NMOS_VTG_PGR_1_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGR_1_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDL_1_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDL_1_0' k1=0.4 u0='u0_NMOS_VTG_PDL_1_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDL_1_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDR_1_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDR_1_0' k1=0.4 u0='u0_NMOS_VTG_PDR_1_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDR_1_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model PMOS_VTG_PUL_1_0 pmos level=54 vth0='vth0_PMOS_VTG_PUL_1_0' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUL_1_0' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUL_1_0' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
.model PMOS_VTG_PUR_1_0 pmos level=54 vth0='vth0_PMOS_VTG_PUR_1_0' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUR_1_0' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUR_1_0' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
RR_Q_0 Q Q_end 100.0Ohm
CCg_Q_0 Q_end 0 0.001pF
RR_QB_0 QB QB_end 100.0Ohm
CCg_QB_0 QB_end 0 0.001pF
MPGL BL WL Q_end VSS NMOS_VTG_PGL_1_0 l=5e-08 w=1.35e-07
MPGR BLB WL QB_end VSS NMOS_VTG_PGR_1_0 l=5e-08 w=1.35e-07
MPDL Q_end QB VSS VSS NMOS_VTG_PDL_1_0 l=5e-08 w=2.05e-07
MPDR QB_end Q VSS VSS NMOS_VTG_PDR_1_0 l=5e-08 w=2.05e-07
MPUL Q_end QB VDD VDD PMOS_VTG_PUL_1_0 l=5e-08 w=9e-08
MPUR QB_end Q VDD VDD PMOS_VTG_PUR_1_0 l=5e-08 w=9e-08
.ends SRAM_6T_CELL_1_0

.subckt SRAM_6T_CELL_1_1 VDD VSS BL BLB WL
.model NMOS_VTG_PGL_1_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGL_1_1' k1=0.4 u0='u0_NMOS_VTG_PGL_1_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGL_1_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PGR_1_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGR_1_1' k1=0.4 u0='u0_NMOS_VTG_PGR_1_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGR_1_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDL_1_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDL_1_1' k1=0.4 u0='u0_NMOS_VTG_PDL_1_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDL_1_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDR_1_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDR_1_1' k1=0.4 u0='u0_NMOS_VTG_PDR_1_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDR_1_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model PMOS_VTG_PUL_1_1 pmos level=54 vth0='vth0_PMOS_VTG_PUL_1_1' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUL_1_1' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUL_1_1' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
.model PMOS_VTG_PUR_1_1 pmos level=54 vth0='vth0_PMOS_VTG_PUR_1_1' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUR_1_1' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUR_1_1' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
RR_Q_0 Q Q_end 100.0Ohm
CCg_Q_0 Q_end 0 0.001pF
RR_QB_0 QB QB_end 100.0Ohm
CCg_QB_0 QB_end 0 0.001pF
MPGL BL WL Q_end VSS NMOS_VTG_PGL_1_1 l=5e-08 w=1.35e-07
MPGR BLB WL QB_end VSS NMOS_VTG_PGR_1_1 l=5e-08 w=1.35e-07
MPDL Q_end QB VSS VSS NMOS_VTG_PDL_1_1 l=5e-08 w=2.05e-07
MPDR QB_end Q VSS VSS NMOS_VTG_PDR_1_1 l=5e-08 w=2.05e-07
MPUL Q_end QB VDD VDD PMOS_VTG_PUL_1_1 l=5e-08 w=9e-08
MPUR QB_end Q VDD VDD PMOS_VTG_PUR_1_1 l=5e-08 w=9e-08
.ends SRAM_6T_CELL_1_1

.subckt SRAM_6T_CELL_2_0 VDD VSS BL BLB WL
.model NMOS_VTG_PGL_2_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGL_2_0' k1=0.4 u0='u0_NMOS_VTG_PGL_2_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGL_2_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PGR_2_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGR_2_0' k1=0.4 u0='u0_NMOS_VTG_PGR_2_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGR_2_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDL_2_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDL_2_0' k1=0.4 u0='u0_NMOS_VTG_PDL_2_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDL_2_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDR_2_0 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDR_2_0' k1=0.4 u0='u0_NMOS_VTG_PDR_2_0' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDR_2_0' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model PMOS_VTG_PUL_2_0 pmos level=54 vth0='vth0_PMOS_VTG_PUL_2_0' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUL_2_0' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUL_2_0' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
.model PMOS_VTG_PUR_2_0 pmos level=54 vth0='vth0_PMOS_VTG_PUR_2_0' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUR_2_0' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUR_2_0' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
RR_Q_0 Q Q_end 100.0Ohm
CCg_Q_0 Q_end 0 0.001pF
RR_QB_0 QB QB_end 100.0Ohm
CCg_QB_0 QB_end 0 0.001pF
MPGL BL WL Q_end VSS NMOS_VTG_PGL_2_0 l=5e-08 w=1.35e-07
MPGR BLB WL QB_end VSS NMOS_VTG_PGR_2_0 l=5e-08 w=1.35e-07
MPDL Q_end QB VSS VSS NMOS_VTG_PDL_2_0 l=5e-08 w=2.05e-07
MPDR QB_end Q VSS VSS NMOS_VTG_PDR_2_0 l=5e-08 w=2.05e-07
MPUL Q_end QB VDD VDD PMOS_VTG_PUL_2_0 l=5e-08 w=9e-08
MPUR QB_end Q VDD VDD PMOS_VTG_PUR_2_0 l=5e-08 w=9e-08
.ends SRAM_6T_CELL_2_0

.subckt SRAM_6T_CELL_2_1 VDD VSS BL BLB WL
.model NMOS_VTG_PGL_2_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGL_2_1' k1=0.4 u0='u0_NMOS_VTG_PGL_2_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGL_2_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PGR_2_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PGR_2_1' k1=0.4 u0='u0_NMOS_VTG_PGR_2_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PGR_2_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDL_2_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDL_2_1' k1=0.4 u0='u0_NMOS_VTG_PDL_2_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDL_2_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model NMOS_VTG_PDR_2_1 nmos level=54 tnom=27 epsrox=3.9 eta0=0.006 nfactor=2.1 wint=5.000e-09 cgso=1.100e-10 cgdo=1.100e-10 xl=-2.000e-08 toxe=1.140e-09 toxp=1.000e-09 toxm=1.140e-09 toxref=1.140e-09 dtox=1.400e-10 lint=3.750e-09 vth0='vth0_NMOS_VTG_PDR_2_1' k1=0.4 u0='u0_NMOS_VTG_PDR_2_1' vsat=123000 rdsw=155 ndep=3.400e+18 xj=1.980e-08 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 k2=0 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=0 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-10 dvtp1=0.1 lpe0=0 lpeb=0 ngate=3.000e+20 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_NMOS_VTG_PDR_2_1' etab=0 vfb=-0.55 ua=6.000e-10 ub=1.200e-18 uc=0 a0=1 ags=0 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0 pclm=0.02 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=1.000e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rsw=80 rdw=80 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.02 bigc=0.0027 cigc=0.002 aigsd=0.02 bigsd=0.0027 cigsd=0.002 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 ngcon=1 
.model PMOS_VTG_PUL_2_1 pmos level=54 vth0='vth0_PMOS_VTG_PUL_2_1' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUL_2_1' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUL_2_1' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
.model PMOS_VTG_PUR_2_1 pmos level=54 vth0='vth0_PMOS_VTG_PUR_2_1' toxref=1.260e-09 vsat=62000 toxe=1.260e-09 toxp=1.000e-09 toxm=1.260e-09 dtox=2.600e-10 epsrox=3.9 wint=5.000e-09 lint=3.750e-09 version=4.8 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=1 igbmod=1 geomod=1 diomod=1 rdsmod=0 rbodymod=1 rgatemod=1 permod=1 acnqsmod=0 trnqsmod=0 tnom=27 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xpart=0 xl=-2.000e-08 k1=0.4 k2=-0.01 k3=0 k3b=0 w0=2.500e-06 dvt0=1 dvt1=2 dvt2=-0.032 dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1.000e-11 dvtp1=0.05 lpe0=0 lpeb=0 xj=1.980e-08 ngate=2.000e+20 ndep=2.440e+18 nsd=2.000e+20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0 voff='voff_PMOS_VTG_PUR_2_1' nfactor=2.22 eta0=0.0055 etab=0 vfb=0.55 u0='u0_PMOS_VTG_PUR_2_1' ua=2.000e-09 ub=5.000e-19 uc=0 a0=1 ags=1.000e-20 a1=0 a2=1 b0=0 b1=0 keta=-0.047 dwg=0 dwb=0 pclm=0.12 pdiblc1=0.001 pdiblc2=0.001 pdiblcb=3.400e-08 drout=0.56 pvag=1.000e-20 delta=0.01 pscbe1=8.140e+08 pscbe2=9.580e-07 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2300000 rsh=5 rdsw=155 rsw=75 rdw=75 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=0 wr=1 alpha0=0.074 alpha1=0.005 beta0=30 agidl=2.000e-04 bgidl=2.100e+09 cgidl=2.000e-04 egidl=0.8 aigbacc=0.012 bigbacc=0.0028 cigbacc=0.002 nigbacc=1 aigbinv=0.014 bigbinv=0.004 cigbinv=0.004 eigbinv=1.1 nigbinv=3 aigc=0.010687 bigc=0.0012607 cigc=8.000e-04 aigsd=0.010687 bigsd=0.0012607 cigsd=8.000e-04 nigc=1 poxedge=1 pigcd=1 ntox=1 xrcrg1=12 xrcrg2=5 cgso=1.100e-10 cgdo=1.100e-10 cgbo=2.560e-11 cgdl=2.653e-10 cgsl=2.653e-10 ckappas=0.03 ckappad=0.03 acde=1 moin=15 noff=0.9 voffcv=0.02 kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.310e-09 ub1=7.610e-18 uc1=-5.600e-11 prt=0 at=33000 fnoimod=1 tnoimod=0 jss=1.000e-04 jsws=1.000e-11 jswgs=1.000e-10 njs=1 ijthsfwd=0.01 ijthsrev=0.001 bvs=10 xjbvs=1 jsd=1.000e-04 jswd=1.000e-11 jswgd=1.000e-10 njd=1 ijthdfwd=0.01 ijthdrev=0.001 bvd=10 xjbvd=1 pbs=1 cjs=5.000e-04 mjs=0.5 pbsws=1 cjsws=5.000e-10 mjsws=0.33 pbswgs=1 cjswgs=3.000e-10 mjswgs=0.33 pbd=1 cjd=5.000e-04 mjd=0.5 pbswd=1 cjswd=5.000e-10 mjswd=0.33 pbswgd=1 cjswgd=5.000e-10 mjswgd=0.33 tpb=0.005 tcj=0.001 tpbsw=0.005 tcjsw=0.001 tpbswg=0.005 tcjswg=0.001 xtis=3 xtid=3 dmcg=0 dmci=0 dmdg=0 dmcgt=0 dwj=0 xgw=0 xgl=0 rshg=0.4 gbmin=1.000e-10 rbpb=5 rbpd=15 rbps=15 rbdb=15 rbsb=15 
RR_Q_0 Q Q_end 100.0Ohm
CCg_Q_0 Q_end 0 0.001pF
RR_QB_0 QB QB_end 100.0Ohm
CCg_QB_0 QB_end 0 0.001pF
MPGL BL WL Q_end VSS NMOS_VTG_PGL_2_1 l=5e-08 w=1.35e-07
MPGR BLB WL QB_end VSS NMOS_VTG_PGR_2_1 l=5e-08 w=1.35e-07
MPDL Q_end QB VSS VSS NMOS_VTG_PDL_2_1 l=5e-08 w=2.05e-07
MPDR QB_end Q VSS VSS NMOS_VTG_PDR_2_1 l=5e-08 w=2.05e-07
MPUL Q_end QB VDD VDD PMOS_VTG_PUL_2_1 l=5e-08 w=9e-08
MPUR QB_end Q VDD VDD PMOS_VTG_PUR_2_1 l=5e-08 w=9e-08
.ends SRAM_6T_CELL_2_1
Rwire_WL0_0 WL0 WL0_tap0 0.5Ohm
Rwire_WL0_1 WL0_tap0 WL0_wire1 0.5Ohm
Rwire_WL0_2 WL0_wire1 WL0_tap1 0.5Ohm
Rwire_WL0_3 WL0_tap1 WL0_far 0.5Ohm
Cwire_WL0_0 WL0 VSS 2.4999999999999996e-17
Cwire_WL0_1 WL0_tap0 VSS 4.999999999999999e-17
Cwire_WL0_2 WL0_wire1 VSS 4.999999999999999e-17
Cwire_WL0_3 WL0_tap1 VSS 4.999999999999999e-17
Cwire_WL0_4 WL0_far VSS 2.4999999999999996e-17
Rwire_WL1_0 WL1 WL1_tap0 0.5Ohm
Rwire_WL1_1 WL1_tap0 WL1_wire1 0.5Ohm
Rwire_WL1_2 WL1_wire1 WL1_tap1 0.5Ohm
Rwire_WL1_3 WL1_tap1 WL1_far 0.5Ohm
Cwire_WL1_0 WL1 VSS 2.4999999999999996e-17
Cwire_WL1_1 WL1_tap0 VSS 4.999999999999999e-17
Cwire_WL1_2 WL1_wire1 VSS 4.999999999999999e-17
Cwire_WL1_3 WL1_tap1 VSS 4.999999999999999e-17
Cwire_WL1_4 WL1_far VSS 2.4999999999999996e-17
Rwire_WL2_0 WL2 WL2_tap0 0.5Ohm
Rwire_WL2_1 WL2_tap0 WL2_wire1 0.5Ohm
Rwire_WL2_2 WL2_wire1 WL2_tap1 0.5Ohm
Rwire_WL2_3 WL2_tap1 WL2_far 0.5Ohm
Cwire_WL2_0 WL2 VSS 2.4999999999999996e-17
Cwire_WL2_1 WL2_tap0 VSS 4.999999999999999e-17
Cwire_WL2_2 WL2_wire1 VSS 4.999999999999999e-17
Cwire_WL2_3 WL2_tap1 VSS 4.999999999999999e-17
Cwire_WL2_4 WL2_far VSS 2.4999999999999996e-17
Rwire_BL0_0 BL0 BL0_tap0 0.5Ohm
Rwire_BL0_1 BL0_tap0 BL0_wire1 0.5Ohm
Rwire_BL0_2 BL0_wire1 BL0_tap1 0.5Ohm
Rwire_BL0_3 BL0_tap1 BL0_wire3 0.5Ohm
Rwire_BL0_4 BL0_wire3 BL0_tap2 0.5Ohm
Rwire_BL0_5 BL0_tap2 BL0_far 0.5Ohm
Cwire_BL0_0 BL0 VSS 2.4999999999999996e-17
Cwire_BL0_1 BL0_tap0 VSS 4.999999999999999e-17
Cwire_BL0_2 BL0_wire1 VSS 4.999999999999999e-17
Cwire_BL0_3 BL0_tap1 VSS 4.999999999999999e-17
Cwire_BL0_4 BL0_wire3 VSS 4.999999999999999e-17
Cwire_BL0_5 BL0_tap2 VSS 4.999999999999999e-17
Cwire_BL0_6 BL0_far VSS 2.4999999999999996e-17
Rwire_BLB0_0 BLB0 BLB0_tap0 0.5Ohm
Rwire_BLB0_1 BLB0_tap0 BLB0_wire1 0.5Ohm
Rwire_BLB0_2 BLB0_wire1 BLB0_tap1 0.5Ohm
Rwire_BLB0_3 BLB0_tap1 BLB0_wire3 0.5Ohm
Rwire_BLB0_4 BLB0_wire3 BLB0_tap2 0.5Ohm
Rwire_BLB0_5 BLB0_tap2 BLB0_far 0.5Ohm
Cwire_BLB0_0 BLB0 VSS 2.4999999999999996e-17
Cwire_BLB0_1 BLB0_tap0 VSS 4.999999999999999e-17
Cwire_BLB0_2 BLB0_wire1 VSS 4.999999999999999e-17
Cwire_BLB0_3 BLB0_tap1 VSS 4.999999999999999e-17
Cwire_BLB0_4 BLB0_wire3 VSS 4.999999999999999e-17
Cwire_BLB0_5 BLB0_tap2 VSS 4.999999999999999e-17
Cwire_BLB0_6 BLB0_far VSS 2.4999999999999996e-17
Rwire_BL1_0 BL1 BL1_tap0 0.5Ohm
Rwire_BL1_1 BL1_tap0 BL1_wire1 0.5Ohm
Rwire_BL1_2 BL1_wire1 BL1_tap1 0.5Ohm
Rwire_BL1_3 BL1_tap1 BL1_wire3 0.5Ohm
Rwire_BL1_4 BL1_wire3 BL1_tap2 0.5Ohm
Rwire_BL1_5 BL1_tap2 BL1_far 0.5Ohm
Cwire_BL1_0 BL1 VSS 2.4999999999999996e-17
Cwire_BL1_1 BL1_tap0 VSS 4.999999999999999e-17
Cwire_BL1_2 BL1_wire1 VSS 4.999999999999999e-17
Cwire_BL1_3 BL1_tap1 VSS 4.999999999999999e-17
Cwire_BL1_4 BL1_wire3 VSS 4.999999999999999e-17
Cwire_BL1_5 BL1_tap2 VSS 4.999999999999999e-17
Cwire_BL1_6 BL1_far VSS 2.4999999999999996e-17
Rwire_BLB1_0 BLB1 BLB1_tap0 0.5Ohm
Rwire_BLB1_1 BLB1_tap0 BLB1_wire1 0.5Ohm
Rwire_BLB1_2 BLB1_wire1 BLB1_tap1 0.5Ohm
Rwire_BLB1_3 BLB1_tap1 BLB1_wire3 0.5Ohm
Rwire_BLB1_4 BLB1_wire3 BLB1_tap2 0.5Ohm
Rwire_BLB1_5 BLB1_tap2 BLB1_far 0.5Ohm
Cwire_BLB1_0 BLB1 VSS 2.4999999999999996e-17
Cwire_BLB1_1 BLB1_tap0 VSS 4.999999999999999e-17
Cwire_BLB1_2 BLB1_wire1 VSS 4.999999999999999e-17
Cwire_BLB1_3 BLB1_tap1 VSS 4.999999999999999e-17
Cwire_BLB1_4 BLB1_wire3 VSS 4.999999999999999e-17
Cwire_BLB1_5 BLB1_tap2 VSS 4.999999999999999e-17
Cwire_BLB1_6 BLB1_far VSS 2.4999999999999996e-17
XSRAM_6T_CELL_0_0 VDD VSS BL0_tap0 BLB0_tap0 WL0_tap0 SRAM_6T_CELL_0_0
XSRAM_6T_CELL_0_1 VDD VSS BL1_tap0 BLB1_tap0 WL0_tap1 SRAM_6T_CELL_0_1
XSRAM_6T_CELL_1_0 VDD VSS BL0_tap1 BLB0_tap1 WL1_tap0 SRAM_6T_CELL_1_0
XSRAM_6T_CELL_1_1 VDD VSS BL1_tap1 BLB1_tap1 WL1_tap1 SRAM_6T_CELL_1_1
XSRAM_6T_CELL_2_0 VDD VSS BL0_tap2 BLB0_tap2 WL2_tap0 SRAM_6T_CELL_2_0
XSRAM_6T_CELL_2_1 VDD VSS BL1_tap2 BLB1_tap2 WL2_tap1 SRAM_6T_CELL_2_1
.ends SRAM_6T_CORE_3x2

.subckt sram_3x1_replica_column VDD VSS RBL RBLB WL0 WL1 WL2
.subckt Replica_CELL VDD VSS RBL RBLB WL
RR_Q_0 Q Q_end 100.0Ohm
CCg_Q_0 Q_end 0 0.001pF
MPGL RBL WL Q_end VSS NMOS_VTG l=5e-08 w=1.35e-07
MPGR RBLB WL VDD VSS NMOS_VTG l=5e-08 w=1.35e-07
MPDL Q_end VDD VSS VSS NMOS_VTG l=5e-08 w=2.05e-07
MPUL Q_end VDD VDD VDD PMOS_VTG l=5e-08 w=9e-08
MPDR VDD Q VSS VSS NMOS_VTG l=5e-08 w=2.05e-07
MPUR VDD Q VDD VDD PMOS_VTG l=5e-08 w=9e-08
.ends Replica_CELL

.subckt Replica_CELL_PASSIVE VDD VSS RBL RBLB WL
RR_Q_0 Q Q_end 100.0Ohm
CCg_Q_0 Q_end 0 0.001pF
MPGL RBL WL Q_end VSS NMOS_VTG l=5e-08 w=1.35e-07
MPGR RBLB WL VDD VSS NMOS_VTG l=5e-08 w=1.35e-07
MPDL Q_end VSS VSS VSS NMOS_VTG l=5e-08 w=2.05e-07
MPUL Q_end VSS VDD VDD PMOS_VTG l=5e-08 w=9e-08
MPDR VDD VSS VSS VSS NMOS_VTG l=5e-08 w=2.05e-07
MPUR VDD VSS VDD VDD PMOS_VTG l=5e-08 w=9e-08
.ends Replica_CELL_PASSIVE
Rwire_RBL_0 RBL RBL_tap0 0.5Ohm
Rwire_RBL_1 RBL_tap0 RBL_wire1 0.5Ohm
Rwire_RBL_2 RBL_wire1 RBL_tap1 0.5Ohm
Rwire_RBL_3 RBL_tap1 RBL_wire3 0.5Ohm
Rwire_RBL_4 RBL_wire3 RBL_tap2 0.5Ohm
Rwire_RBL_5 RBL_tap2 RBL_far 0.5Ohm
Cwire_RBL_0 RBL VSS 2.4999999999999996e-17
Cwire_RBL_1 RBL_tap0 VSS 4.999999999999999e-17
Cwire_RBL_2 RBL_wire1 VSS 4.999999999999999e-17
Cwire_RBL_3 RBL_tap1 VSS 4.999999999999999e-17
Cwire_RBL_4 RBL_wire3 VSS 4.999999999999999e-17
Cwire_RBL_5 RBL_tap2 VSS 4.999999999999999e-17
Cwire_RBL_6 RBL_far VSS 2.4999999999999996e-17
Rwire_RBLB_0 RBLB RBLB_tap0 0.5Ohm
Rwire_RBLB_1 RBLB_tap0 RBLB_wire1 0.5Ohm
Rwire_RBLB_2 RBLB_wire1 RBLB_tap1 0.5Ohm
Rwire_RBLB_3 RBLB_tap1 RBLB_wire3 0.5Ohm
Rwire_RBLB_4 RBLB_wire3 RBLB_tap2 0.5Ohm
Rwire_RBLB_5 RBLB_tap2 RBLB_far 0.5Ohm
Cwire_RBLB_0 RBLB VSS 2.4999999999999996e-17
Cwire_RBLB_1 RBLB_tap0 VSS 4.999999999999999e-17
Cwire_RBLB_2 RBLB_wire1 VSS 4.999999999999999e-17
Cwire_RBLB_3 RBLB_tap1 VSS 4.999999999999999e-17
Cwire_RBLB_4 RBLB_wire3 VSS 4.999999999999999e-17
Cwire_RBLB_5 RBLB_tap2 VSS 4.999999999999999e-17
Cwire_RBLB_6 RBLB_far VSS 2.4999999999999996e-17
XReplica_CELL_0 VDD VSS RBL_tap0 RBLB_tap0 WL0 Replica_CELL_PASSIVE
XReplica_CELL_1 VDD VSS RBL_tap1 RBLB_tap1 WL1 Replica_CELL_PASSIVE
XReplica_CELL_2 VDD VSS RBL_tap2 RBLB_tap2 WL2 Replica_CELL
.ends sram_3x1_replica_column

.subckt WORDLINEDRIVER VDD VSS A B Z
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV
RR_A_0 A A_seg0 100.0Ohm
CCg_A_0 A_seg0 0 0.001pF
RR_A_1 A_seg0 A_end 100.0Ohm
CCg_A_1 A_end 0 0.001pF
RR_B_0 B B_seg0 100.0Ohm
CCg_B_0 B_seg0 0 0.001pF
RR_B_1 B_seg0 B_end 100.0Ohm
CCg_B_1 B_end 0 0.001pF
RR_zb_int_0 zb_int zb_int_seg0 100.0Ohm
CCg_zb_int_0 zb_int_seg0 0 0.001pF
RR_zb_int_1 zb_int_seg0 zb_int_end 100.0Ohm
CCg_zb_int_1 zb_int_end 0 0.001pF
RR_Z_0 Z Z_seg0 100.0Ohm
CCg_Z_0 Z_seg0 0 0.001pF
RR_Z_1 Z_seg0 Z_end 100.0Ohm
CCg_Z_1 Z_end 0 0.001pF
XPNAND2 VDD VSS A_end B_end zb_int PNAND2
XPINV VDD VSS zb_int_end Z_end PINV
.ends WORDLINEDRIVER

.subckt Dummy_CELL VDD VSS BL BLB WL
RR_Q_0 Q Q_end 100.0Ohm
CCg_Q_0 Q_end 0 0.001pF
MPDL Q_end VDD VSS VSS NMOS_VTG l=5e-08 w=2.05e-07
MPDR VDD Q_end VSS VSS NMOS_VTG l=5e-08 w=2.05e-07
MPUL Q_end VDD VDD VDD PMOS_VTG l=5e-08 w=9e-08
MPUR VDD Q_end VDD VDD PMOS_VTG l=5e-08 w=9e-08
MPGL bl_node_noconnect WL Q_end VSS NMOS_VTG l=5e-08 w=1.35e-07
MPGR blb_node_noconnect WL VDD VSS NMOS_VTG l=5e-08 w=1.35e-07
.ends Dummy_CELL

.subckt TIME_CONTROL VDD VSS clk csb web clk_buf clk_bar cs_bar cs we_bar we gated_clk_bar gated_clk_buf wl_en A0 A1 A_dff0 A_dff1 rbl rbl_delay rbl_delay_bar s_en w_en PRE sa_iso rwl pre_far iso_far sen_far wen_far
.subckt ADDRESS_REGISTER VDD VSS CLK A0 A1 A_dff0 A_dff1
.subckt DFF VDD VSS D Q CLK
.subckt PINV1 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=5e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=2.5e-07
.ends PINV1

.subckt TRANSMISSION_GATE VDD VSS IN OUT CTR_P CTR_N
Mtranspmos OUT CTR_P IN VDD PMOS_VTG l=5e-08 w=5e-07
Mtransnmos IN CTR_N OUT VSS NMOS_VTG l=5e-08 w=2.5e-07
.ends TRANSMISSION_GATE
Xinv1_clk VDD VSS CLK CLKB PINV1
Xinv2_D VDD VSS D D_b PINV1
Xtg1 VDD VSS D_b z1 CLK CLKB TRANSMISSION_GATE
Xinv3 VDD VSS z1 z2 PINV1
Xinv4 VDD VSS z2 z3 PINV1
Xtg2 VDD VSS z3 z1 CLKB CLK TRANSMISSION_GATE
Xinv5 VDD VSS z2 z4 PINV1
Xtg3 VDD VSS z4 z5 CLKB CLK TRANSMISSION_GATE
Xinv6 VDD VSS z5 Q PINV1
Xinv7 VDD VSS Q QB PINV1
Xtg4 VDD VSS QB z5 CLK CLKB TRANSMISSION_GATE
.ends DFF
Xdff_0 VDD VSS A0 A_dff0 CLK DFF
Xdff_1 VDD VSS A1 A_dff1 CLK DFF
.ends ADDRESS_REGISTER

.subckt ADDRESS_BUFFER VDD VSS A Z
.subckt PINV_ADDRESS_BUFFER_0 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_ADDRESS_BUFFER_0

.subckt PINV_ADDRESS_BUFFER_1 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_ADDRESS_BUFFER_1
Xinv0 VDD VSS A b0 PINV_ADDRESS_BUFFER_0
Xinv1 VDD VSS b0 Z PINV_ADDRESS_BUFFER_1
.ends ADDRESS_BUFFER

.subckt CLOCK_BUFFER VDD VSS A Z
.subckt PINV1 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV1

.subckt PINV2 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=8.1e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=2.7e-07
.ends PINV2

.subckt PINV3 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.43e-06 NF=2
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9.1e-07
.ends PINV3

.subckt PINV4 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=7.3e-06 NF=4
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=2.43e-06 NF=2
.ends PINV4
Xbuf_inv1 VDD VSS A zb1_node PINV1
Xbuf_inv2 VDD VSS zb1_node zb2_node PINV2
Xbuf_inv3 VDD VSS zb2_node zb3_node PINV3
Xbuf_inv4 VDD VSS zb3_node Z PINV4
.ends CLOCK_BUFFER

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV

.subckt DFF_BUFFER VDD VSS D Q QB CLK
.subckt DFF VDD VSS D Q CLK
.subckt PINV1 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=5e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=2.5e-07
.ends PINV1

.subckt TRANSMISSION_GATE VDD VSS IN OUT CTR_P CTR_N
Mtranspmos OUT CTR_P IN VDD PMOS_VTG l=5e-08 w=5e-07
Mtransnmos IN CTR_N OUT VSS NMOS_VTG l=5e-08 w=2.5e-07
.ends TRANSMISSION_GATE
Xinv1_clk VDD VSS CLK CLKB PINV1
Xinv2_D VDD VSS D D_b PINV1
Xtg1 VDD VSS D_b z1 CLK CLKB TRANSMISSION_GATE
Xinv3 VDD VSS z1 z2 PINV1
Xinv4 VDD VSS z2 z3 PINV1
Xtg2 VDD VSS z3 z1 CLKB CLK TRANSMISSION_GATE
Xinv5 VDD VSS z2 z4 PINV1
Xtg3 VDD VSS z4 z5 CLKB CLK TRANSMISSION_GATE
Xinv6 VDD VSS z5 Q PINV1
Xinv7 VDD VSS Q QB PINV1
Xtg4 VDD VSS QB z5 CLK CLKB TRANSMISSION_GATE
.ends DFF

.subckt PINV1 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PINV1

.subckt PINV2 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.08e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=3.6e-07
.ends PINV2
Xdff VDD VSS D qint CLK DFF
Xinv1 VDD VSS qint QB PINV1
Xinv2 VDD VSS QB Q PINV2
.ends DFF_BUFFER

.subckt AND2 VDD VSS A B Z
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.62e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=5.4e-07
.ends PINV
XPNAND3 VDD VSS A B zb_int PNAND2
XPINV VDD VSS zb_int Z PINV
.ends AND2

.subckt PRECHARGE_OFF_GUARD VDD VSS request pre_far access pre_off_ready
.subckt PINV_pre_off_observer VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_pre_off_observer

.subckt PRECHARGE_OFF_DELAY VDD VSS in out
.subckt PINV_unit_delay VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.16e-06 NF=2
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=7.2e-07
.ends PINV_unit_delay

.subckt PINV_unit_delay_load VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_unit_delay_load
Xwinv0 VDD VSS in wen_dly_1 PINV_unit_delay
Xwload_0_0 VDD VSS wen_dly_1 wn_0_0 PINV_unit_delay_load
Xwload_0_1 VDD VSS wen_dly_1 wn_0_1 PINV_unit_delay_load
Xwload_0_2 VDD VSS wen_dly_1 wn_0_2 PINV_unit_delay_load
Xwload_0_3 VDD VSS wen_dly_1 wn_0_3 PINV_unit_delay_load
Xwinv1 VDD VSS wen_dly_1 wen_dly_2 PINV_unit_delay
Xwload_1_0 VDD VSS wen_dly_2 wn_1_0 PINV_unit_delay_load
Xwload_1_1 VDD VSS wen_dly_2 wn_1_1 PINV_unit_delay_load
Xwload_1_2 VDD VSS wen_dly_2 wn_1_2 PINV_unit_delay_load
Xwload_1_3 VDD VSS wen_dly_2 wn_1_3 PINV_unit_delay_load
Xwinv2 VDD VSS wen_dly_2 wen_dly_3 PINV_unit_delay
Xwload_2_0 VDD VSS wen_dly_3 wn_2_0 PINV_unit_delay_load
Xwload_2_1 VDD VSS wen_dly_3 wn_2_1 PINV_unit_delay_load
Xwload_2_2 VDD VSS wen_dly_3 wn_2_2 PINV_unit_delay_load
Xwload_2_3 VDD VSS wen_dly_3 wn_2_3 PINV_unit_delay_load
Xwinv3 VDD VSS wen_dly_3 out PINV_unit_delay
Xwload_3_0 VDD VSS out wn_3_0 PINV_unit_delay_load
Xwload_3_1 VDD VSS out wn_3_1 PINV_unit_delay_load
Xwload_3_2 VDD VSS out wn_3_2 PINV_unit_delay_load
Xwload_3_3 VDD VSS out wn_3_3 PINV_unit_delay_load
.ends PRECHARGE_OFF_DELAY

.subckt PNOR2 VDD VSS A B Z
Mpnor2_pmos1 net1 A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_pmos2 Z B net1 VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_nmos1 Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
Mpnor2_nmos2 Z B VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PNOR2

.subckt PRECHARGE_ACCESS_AND VDD VSS A B Z
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.6200000000000002e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=5.4e-07
.ends PINV
XPNAND3 VDD VSS A B zb_int PNAND2
XPINV VDD VSS zb_int Z PINV
.ends PRECHARGE_ACCESS_AND
Xobserve_pre VDD VSS pre_far pre_on PINV_pre_off_observer
Xsettle_pre VDD VSS pre_on pre_on_delayed PRECHARGE_OFF_DELAY
Xready VDD VSS pre_on pre_on_delayed pre_off_ready PNOR2
Xrequest_gate VDD VSS request pre_off_ready access PRECHARGE_ACCESS_AND
.ends PRECHARGE_OFF_GUARD

.subckt WRITE_READY_NOR VDD VSS A B Z
Mpnor2_pmos1 net1 A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_pmos2 Z B net1 VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_nmos1 Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
Mpnor2_nmos2 Z B VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends WRITE_READY_NOR

.subckt PINV_write_ready VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_write_ready

.subckt WORDLINE_START_AND VDD VSS A B Z
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.62e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=5.4e-07
.ends PINV
XPNAND3 VDD VSS A B zb_int PNAND2
XPINV VDD VSS zb_int Z PINV
.ends WORDLINE_START_AND

.subckt WORDLINE_SETUP_DELAY VDD VSS in out
.subckt PINV_unit_delay VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.16e-06 NF=2
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=7.2e-07
.ends PINV_unit_delay

.subckt PINV_unit_delay_load VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_unit_delay_load
Xwinv0 VDD VSS in wen_dly_1 PINV_unit_delay
Xwload_0_0 VDD VSS wen_dly_1 wn_0_0 PINV_unit_delay_load
Xwload_0_1 VDD VSS wen_dly_1 wn_0_1 PINV_unit_delay_load
Xwload_0_2 VDD VSS wen_dly_1 wn_0_2 PINV_unit_delay_load
Xwload_0_3 VDD VSS wen_dly_1 wn_0_3 PINV_unit_delay_load
Xwinv1 VDD VSS wen_dly_1 wen_dly_2 PINV_unit_delay
Xwload_1_0 VDD VSS wen_dly_2 wn_1_0 PINV_unit_delay_load
Xwload_1_1 VDD VSS wen_dly_2 wn_1_1 PINV_unit_delay_load
Xwload_1_2 VDD VSS wen_dly_2 wn_1_2 PINV_unit_delay_load
Xwload_1_3 VDD VSS wen_dly_2 wn_1_3 PINV_unit_delay_load
Xwinv2 VDD VSS wen_dly_2 wen_dly_3 PINV_unit_delay
Xwload_2_0 VDD VSS wen_dly_3 wn_2_0 PINV_unit_delay_load
Xwload_2_1 VDD VSS wen_dly_3 wn_2_1 PINV_unit_delay_load
Xwload_2_2 VDD VSS wen_dly_3 wn_2_2 PINV_unit_delay_load
Xwload_2_3 VDD VSS wen_dly_3 wn_2_3 PINV_unit_delay_load
Xwinv3 VDD VSS wen_dly_3 wen_dly_4 PINV_unit_delay
Xwload_3_0 VDD VSS wen_dly_4 wn_3_0 PINV_unit_delay_load
Xwload_3_1 VDD VSS wen_dly_4 wn_3_1 PINV_unit_delay_load
Xwload_3_2 VDD VSS wen_dly_4 wn_3_2 PINV_unit_delay_load
Xwload_3_3 VDD VSS wen_dly_4 wn_3_3 PINV_unit_delay_load
Xwinv4 VDD VSS wen_dly_4 wen_dly_5 PINV_unit_delay
Xwload_4_0 VDD VSS wen_dly_5 wn_4_0 PINV_unit_delay_load
Xwload_4_1 VDD VSS wen_dly_5 wn_4_1 PINV_unit_delay_load
Xwload_4_2 VDD VSS wen_dly_5 wn_4_2 PINV_unit_delay_load
Xwload_4_3 VDD VSS wen_dly_5 wn_4_3 PINV_unit_delay_load
Xwinv5 VDD VSS wen_dly_5 wen_dly_6 PINV_unit_delay
Xwload_5_0 VDD VSS wen_dly_6 wn_5_0 PINV_unit_delay_load
Xwload_5_1 VDD VSS wen_dly_6 wn_5_1 PINV_unit_delay_load
Xwload_5_2 VDD VSS wen_dly_6 wn_5_2 PINV_unit_delay_load
Xwload_5_3 VDD VSS wen_dly_6 wn_5_3 PINV_unit_delay_load
Xwinv6 VDD VSS wen_dly_6 wen_dly_7 PINV_unit_delay
Xwload_6_0 VDD VSS wen_dly_7 wn_6_0 PINV_unit_delay_load
Xwload_6_1 VDD VSS wen_dly_7 wn_6_1 PINV_unit_delay_load
Xwload_6_2 VDD VSS wen_dly_7 wn_6_2 PINV_unit_delay_load
Xwload_6_3 VDD VSS wen_dly_7 wn_6_3 PINV_unit_delay_load
Xwinv7 VDD VSS wen_dly_7 out PINV_unit_delay
Xwload_7_0 VDD VSS out wn_7_0 PINV_unit_delay_load
Xwload_7_1 VDD VSS out wn_7_1 PINV_unit_delay_load
Xwload_7_2 VDD VSS out wn_7_2 PINV_unit_delay_load
Xwload_7_3 VDD VSS out wn_7_3 PINV_unit_delay_load
.ends WORDLINE_SETUP_DELAY

.subckt WORDLINE_SETUP_AND VDD VSS A B Z
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.62e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=5.4e-07
.ends PINV
XPNAND3 VDD VSS A B zb_int PNAND2
XPINV VDD VSS zb_int Z PINV
.ends WORDLINE_SETUP_AND

.subckt WORDLINE_ENABLE_BUFFER VDD VSS A B Z
.subckt WORDLINE_REQUEST_NAND VDD VSS A B Z
Mpmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mnmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mnmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends WORDLINE_REQUEST_NAND

.subckt PINV2 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.35e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=4.5000000000000003e-07
.ends PINV2
Xbuf_nand1 VDD VSS A B zb1_node WORDLINE_REQUEST_NAND
Xbuf_inv2 VDD VSS zb1_node Z PINV2
.ends WORDLINE_ENABLE_BUFFER

.subckt PINV_wl_en_bar VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PINV_wl_en_bar

.subckt REPLICA_DELAY_CHAIN VDD VSS in out
.subckt PINV_replica_driver VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.08e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=3.6e-07
.ends PINV_replica_driver

.subckt PINV_replica_load VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_replica_load
Xdinv0 VDD VSS in dout_1 PINV_replica_driver
Xdload_0_0 VDD VSS dout_1 n_0_0 PINV_replica_load
Xdload_0_1 VDD VSS dout_1 n_0_1 PINV_replica_load
Xdload_0_2 VDD VSS dout_1 n_0_2 PINV_replica_load
Xdload_0_3 VDD VSS dout_1 n_0_3 PINV_replica_load
Xdinv1 VDD VSS dout_1 dout_2 PINV_replica_driver
Xdload_1_0 VDD VSS dout_2 n_1_0 PINV_replica_load
Xdload_1_1 VDD VSS dout_2 n_1_1 PINV_replica_load
Xdload_1_2 VDD VSS dout_2 n_1_2 PINV_replica_load
Xdload_1_3 VDD VSS dout_2 n_1_3 PINV_replica_load
Xdinv2 VDD VSS dout_2 dout_3 PINV_replica_driver
Xdload_2_0 VDD VSS dout_3 n_2_0 PINV_replica_load
Xdload_2_1 VDD VSS dout_3 n_2_1 PINV_replica_load
Xdload_2_2 VDD VSS dout_3 n_2_2 PINV_replica_load
Xdload_2_3 VDD VSS dout_3 n_2_3 PINV_replica_load
Xdinv3 VDD VSS dout_3 dout_4 PINV_replica_driver
Xdload_3_0 VDD VSS dout_4 n_3_0 PINV_replica_load
Xdload_3_1 VDD VSS dout_4 n_3_1 PINV_replica_load
Xdload_3_2 VDD VSS dout_4 n_3_2 PINV_replica_load
Xdload_3_3 VDD VSS dout_4 n_3_3 PINV_replica_load
Xdinv4 VDD VSS dout_4 dout_5 PINV_replica_driver
Xdload_4_0 VDD VSS dout_5 n_4_0 PINV_replica_load
Xdload_4_1 VDD VSS dout_5 n_4_1 PINV_replica_load
Xdload_4_2 VDD VSS dout_5 n_4_2 PINV_replica_load
Xdload_4_3 VDD VSS dout_5 n_4_3 PINV_replica_load
Xdinv5 VDD VSS dout_5 dout_6 PINV_replica_driver
Xdload_5_0 VDD VSS dout_6 n_5_0 PINV_replica_load
Xdload_5_1 VDD VSS dout_6 n_5_1 PINV_replica_load
Xdload_5_2 VDD VSS dout_6 n_5_2 PINV_replica_load
Xdload_5_3 VDD VSS dout_6 n_5_3 PINV_replica_load
Xdinv6 VDD VSS dout_6 dout_7 PINV_replica_driver
Xdload_6_0 VDD VSS dout_7 n_6_0 PINV_replica_load
Xdload_6_1 VDD VSS dout_7 n_6_1 PINV_replica_load
Xdload_6_2 VDD VSS dout_7 n_6_2 PINV_replica_load
Xdload_6_3 VDD VSS dout_7 n_6_3 PINV_replica_load
Xdinv7 VDD VSS dout_7 dout_8 PINV_replica_driver
Xdload_7_0 VDD VSS dout_8 n_7_0 PINV_replica_load
Xdload_7_1 VDD VSS dout_8 n_7_1 PINV_replica_load
Xdload_7_2 VDD VSS dout_8 n_7_2 PINV_replica_load
Xdload_7_3 VDD VSS dout_8 n_7_3 PINV_replica_load
Xdinv8 VDD VSS dout_8 out PINV_replica_driver
Xdload_8_0 VDD VSS out n_8_0 PINV_replica_load
Xdload_8_1 VDD VSS out n_8_1 PINV_replica_load
Xdload_8_2 VDD VSS out n_8_2 PINV_replica_load
Xdload_8_3 VDD VSS out n_8_3 PINV_replica_load
.ends REPLICA_DELAY_CHAIN

.subckt READ_DONE_AND VDD VSS A B C Z
.subckt PNAND3 VDD VSS A B C Z
Mpnand3_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_pmos3 Z C VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_nmos1 Z A net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand3_nmos2 net1 B net2 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand3_nmos3 net2 C VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND3

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.08e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=3.6e-07
.ends PINV
XPNAND3 VDD VSS A B C zb_int PNAND3
XPINV VDD VSS zb_int Z PINV
.ends READ_DONE_AND

.subckt PINV_read_done_bar VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_read_done_bar

.subckt PINV_rwl_precharge VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_rwl_precharge

.subckt PRECHARGE_GUARD_DELAY VDD VSS in out
.subckt PINV_unit_delay VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.16e-06 NF=2
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=7.2e-07
.ends PINV_unit_delay

.subckt PINV_unit_delay_load VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_unit_delay_load
Xwinv0 VDD VSS in wen_dly_1 PINV_unit_delay
Xwload_0_0 VDD VSS wen_dly_1 wn_0_0 PINV_unit_delay_load
Xwload_0_1 VDD VSS wen_dly_1 wn_0_1 PINV_unit_delay_load
Xwload_0_2 VDD VSS wen_dly_1 wn_0_2 PINV_unit_delay_load
Xwload_0_3 VDD VSS wen_dly_1 wn_0_3 PINV_unit_delay_load
Xwinv1 VDD VSS wen_dly_1 wen_dly_2 PINV_unit_delay
Xwload_1_0 VDD VSS wen_dly_2 wn_1_0 PINV_unit_delay_load
Xwload_1_1 VDD VSS wen_dly_2 wn_1_1 PINV_unit_delay_load
Xwload_1_2 VDD VSS wen_dly_2 wn_1_2 PINV_unit_delay_load
Xwload_1_3 VDD VSS wen_dly_2 wn_1_3 PINV_unit_delay_load
Xwinv2 VDD VSS wen_dly_2 wen_dly_3 PINV_unit_delay
Xwload_2_0 VDD VSS wen_dly_3 wn_2_0 PINV_unit_delay_load
Xwload_2_1 VDD VSS wen_dly_3 wn_2_1 PINV_unit_delay_load
Xwload_2_2 VDD VSS wen_dly_3 wn_2_2 PINV_unit_delay_load
Xwload_2_3 VDD VSS wen_dly_3 wn_2_3 PINV_unit_delay_load
Xwinv3 VDD VSS wen_dly_3 out PINV_unit_delay
Xwload_3_0 VDD VSS out wn_3_0 PINV_unit_delay_load
Xwload_3_1 VDD VSS out wn_3_1 PINV_unit_delay_load
Xwload_3_2 VDD VSS out wn_3_2 PINV_unit_delay_load
Xwload_3_3 VDD VSS out wn_3_3 PINV_unit_delay_load
.ends PRECHARGE_GUARD_DELAY

.subckt PRECHARGE_GUARD_AND VDD VSS A B Z
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV
XPNAND3 VDD VSS A B zb_int PNAND2
XPINV VDD VSS zb_int Z PINV
.ends PRECHARGE_GUARD_AND

.subckt WORDLINE_BUSY_NAND VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends WORDLINE_BUSY_NAND

.subckt PINV_wordline_idle VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_wordline_idle

.subckt WRITE_WINDOW_NOR VDD VSS A B Z
Mpnor2_pmos1 net1 A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_pmos2 Z B net1 VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_nmos1 Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
Mpnor2_nmos2 Z B VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends WRITE_WINDOW_NOR

.subckt PINV_write_window VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_write_window

.subckt GUARDED_WRITE_AND VDD VSS A B C Z
.subckt PNAND3 VDD VSS A B C Z
Mpnand3_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_pmos3 Z C VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_nmos1 Z A net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand3_nmos2 net1 B net2 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand3_nmos3 net2 C VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND3

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.08e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=3.6e-07
.ends PINV
XPNAND3 VDD VSS A B C zb_int PNAND3
XPINV VDD VSS zb_int Z PINV
.ends GUARDED_WRITE_AND

.subckt AND3 VDD VSS A B C Z
.subckt PNAND3 VDD VSS A B C Z
Mpnand3_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_pmos3 Z C VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_nmos1 Z A net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand3_nmos2 net1 B net2 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand3_nmos3 net2 C VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND3

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.08e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=3.6e-07
.ends PINV
XPNAND3 VDD VSS A B C zb_int PNAND3
XPINV VDD VSS zb_int Z PINV
.ends AND3

.subckt SENSE_ENABLE_BUFFER VDD VSS A Z
.subckt PINV_SENSE_ENABLE_BUFFER_0 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=7.15e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=2.4000000000000003e-07
.ends PINV_SENSE_ENABLE_BUFFER_0

.subckt PINV_SENSE_ENABLE_BUFFER_1 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.8900000000000001e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=6.3e-07
.ends PINV_SENSE_ENABLE_BUFFER_1
Xinv0 VDD VSS A b0 PINV_SENSE_ENABLE_BUFFER_0
Xinv1 VDD VSS b0 Z PINV_SENSE_ENABLE_BUFFER_1
.ends SENSE_ENABLE_BUFFER

.subckt WRITE_PREPARE_AND VDD VSS A B Z
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.08e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=3.6e-07
.ends PINV
XPNAND3 VDD VSS A B zb_int PNAND2
XPINV VDD VSS zb_int Z PINV
.ends WRITE_PREPARE_AND

.subckt ISOLATION_REQUEST_NOR VDD VSS A B Z
Mpnor2_pmos1 net1 A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_pmos2 Z B net1 VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_nmos1 Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
Mpnor2_nmos2 Z B VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends ISOLATION_REQUEST_NOR

.subckt ISOLATION_NAND VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=1.08e-06
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=1.08e-06
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=7.2e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=7.2e-07
.ends ISOLATION_NAND

.subckt SENSE_ISOLATION_BUFFER VDD VSS A Z
.subckt PINV_SENSE_ISOLATION_BUFFER_0 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=7.65e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=2.55e-07
.ends PINV_SENSE_ISOLATION_BUFFER_0

.subckt PINV_SENSE_ISOLATION_BUFFER_1 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.16e-06 NF=2
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=1.44e-06
.ends PINV_SENSE_ISOLATION_BUFFER_1
Xinv0 VDD VSS A b0 PINV_SENSE_ISOLATION_BUFFER_0
Xinv1 VDD VSS b0 Z PINV_SENSE_ISOLATION_BUFFER_1
.ends SENSE_ISOLATION_BUFFER

.subckt ISOLATION_OFF_GUARD VDD VSS request pre_far access pre_off_ready
.subckt PINV_pre_off_observer VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_pre_off_observer

.subckt PRECHARGE_OFF_DELAY VDD VSS in out
.subckt PINV_unit_delay VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.16e-06 NF=2
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=7.2e-07
.ends PINV_unit_delay

.subckt PINV_unit_delay_load VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_unit_delay_load
Xwinv0 VDD VSS in wen_dly_1 PINV_unit_delay
Xwload_0_0 VDD VSS wen_dly_1 wn_0_0 PINV_unit_delay_load
Xwload_0_1 VDD VSS wen_dly_1 wn_0_1 PINV_unit_delay_load
Xwload_0_2 VDD VSS wen_dly_1 wn_0_2 PINV_unit_delay_load
Xwload_0_3 VDD VSS wen_dly_1 wn_0_3 PINV_unit_delay_load
Xwinv1 VDD VSS wen_dly_1 wen_dly_2 PINV_unit_delay
Xwload_1_0 VDD VSS wen_dly_2 wn_1_0 PINV_unit_delay_load
Xwload_1_1 VDD VSS wen_dly_2 wn_1_1 PINV_unit_delay_load
Xwload_1_2 VDD VSS wen_dly_2 wn_1_2 PINV_unit_delay_load
Xwload_1_3 VDD VSS wen_dly_2 wn_1_3 PINV_unit_delay_load
Xwinv2 VDD VSS wen_dly_2 wen_dly_3 PINV_unit_delay
Xwload_2_0 VDD VSS wen_dly_3 wn_2_0 PINV_unit_delay_load
Xwload_2_1 VDD VSS wen_dly_3 wn_2_1 PINV_unit_delay_load
Xwload_2_2 VDD VSS wen_dly_3 wn_2_2 PINV_unit_delay_load
Xwload_2_3 VDD VSS wen_dly_3 wn_2_3 PINV_unit_delay_load
Xwinv3 VDD VSS wen_dly_3 out PINV_unit_delay
Xwload_3_0 VDD VSS out wn_3_0 PINV_unit_delay_load
Xwload_3_1 VDD VSS out wn_3_1 PINV_unit_delay_load
Xwload_3_2 VDD VSS out wn_3_2 PINV_unit_delay_load
Xwload_3_3 VDD VSS out wn_3_3 PINV_unit_delay_load
.ends PRECHARGE_OFF_DELAY

.subckt PNOR2 VDD VSS A B Z
Mpnor2_pmos1 net1 A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_pmos2 Z B net1 VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_nmos1 Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
Mpnor2_nmos2 Z B VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PNOR2

.subckt PRECHARGE_ACCESS_AND VDD VSS A B Z
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.6200000000000002e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=5.4e-07
.ends PINV
XPNAND3 VDD VSS A B zb_int PNAND2
XPINV VDD VSS zb_int Z PINV
.ends PRECHARGE_ACCESS_AND
Xobserve_pre VDD VSS pre_far pre_on PINV_pre_off_observer
Xsettle_pre VDD VSS pre_on pre_on_delayed PRECHARGE_OFF_DELAY
Xready VDD VSS pre_on pre_on_delayed pre_off_ready PNOR2
Xrequest_gate VDD VSS request pre_off_ready access PRECHARGE_ACCESS_AND
.ends ISOLATION_OFF_GUARD

.subckt PNAND3 VDD VSS A B C Z
Mpnand3_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_pmos3 Z C VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_nmos1 Z A net1 VSS NMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_nmos2 net1 B net2 VSS NMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_nmos3 net2 C VSS VSS NMOS_VTG l=5e-08 w=2.7e-07
.ends PNAND3

.subckt PRECHARGE_BUFFER VDD VSS A Z
.subckt PINV_PRECHARGE_BUFFER_0 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PINV_PRECHARGE_BUFFER_0

.subckt PINV_PRECHARGE_BUFFER_1 VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.08e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=3.6e-07
.ends PINV_PRECHARGE_BUFFER_1
Xinv0 VDD VSS A b0 PINV_PRECHARGE_BUFFER_0
Xinv1 VDD VSS b0 Z PINV_PRECHARGE_BUFFER_1
.ends PRECHARGE_BUFFER

.subckt PINV_s_en_bar VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_s_en_bar

.subckt ENABLES_OFF_NOR VDD VSS A B Z
Mpnor2_pmos1 net1 A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_pmos2 Z B net1 VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_nmos1 Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
Mpnor2_nmos2 Z B VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends ENABLES_OFF_NOR

.subckt FAR_ENABLES_OFF_NOR VDD VSS A B Z
Mpnor2_pmos1 net1 A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_pmos2 Z B net1 VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_nmos1 Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
Mpnor2_nmos2 Z B VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends FAR_ENABLES_OFF_NOR

.subckt ENABLE_OFF_GUARD VDD VSS request pre_far access pre_off_ready
.subckt PINV_pre_off_observer VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_pre_off_observer

.subckt PRECHARGE_OFF_DELAY VDD VSS in out
.subckt PINV_unit_delay VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.16e-06 NF=2
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=7.2e-07
.ends PINV_unit_delay

.subckt PINV_unit_delay_load VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV_unit_delay_load
Xwinv0 VDD VSS in wen_dly_1 PINV_unit_delay
Xwload_0_0 VDD VSS wen_dly_1 wn_0_0 PINV_unit_delay_load
Xwload_0_1 VDD VSS wen_dly_1 wn_0_1 PINV_unit_delay_load
Xwload_0_2 VDD VSS wen_dly_1 wn_0_2 PINV_unit_delay_load
Xwload_0_3 VDD VSS wen_dly_1 wn_0_3 PINV_unit_delay_load
Xwinv1 VDD VSS wen_dly_1 out PINV_unit_delay
Xwload_1_0 VDD VSS out wn_1_0 PINV_unit_delay_load
Xwload_1_1 VDD VSS out wn_1_1 PINV_unit_delay_load
Xwload_1_2 VDD VSS out wn_1_2 PINV_unit_delay_load
Xwload_1_3 VDD VSS out wn_1_3 PINV_unit_delay_load
.ends PRECHARGE_OFF_DELAY

.subckt PNOR2 VDD VSS A B Z
Mpnor2_pmos1 net1 A VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_pmos2 Z B net1 VDD PMOS_VTG l=5e-08 w=5.4e-07
Mpnor2_nmos1 Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
Mpnor2_nmos2 Z B VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PNOR2

.subckt PRECHARGE_ACCESS_AND VDD VSS A B Z
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=1.6200000000000002e-06
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=5.4e-07
.ends PINV
XPNAND3 VDD VSS A B zb_int PNAND2
XPINV VDD VSS zb_int Z PINV
.ends PRECHARGE_ACCESS_AND
Xobserve_pre VDD VSS pre_far pre_on PINV_pre_off_observer
Xsettle_pre VDD VSS pre_on pre_on_delayed PRECHARGE_OFF_DELAY
Xready VDD VSS pre_on pre_on_delayed pre_off_ready PNOR2
Xrequest_gate VDD VSS request pre_off_ready access PRECHARGE_ACCESS_AND
.ends ENABLE_OFF_GUARD
Xdff_buf_addr VDD VSS clk_buf A0 A1 A_reg0 A_reg1 ADDRESS_REGISTER
Xaddr_buf_0 VDD VSS A_reg0 A_dff0 ADDRESS_BUFFER
Xaddr_buf_1 VDD VSS A_reg1 A_dff1 ADDRESS_BUFFER
Xclkbuf VDD VSS clk clk_buf CLOCK_BUFFER
Xinv_clk_bar VDD VSS clk_buf clk_bar PINV
Xdff_buf VDD VSS csb cs_bar cs clk_buf DFF_BUFFER
Xdff_buf1 VDD VSS web we_bar we clk_buf DFF_BUFFER
Xand2_gated_clk_bar VDD VSS cs clk_bar gated_clk_bar AND2
Xand2_gated_clk_buf VDD VSS cs clk_buf gated_clk_buf AND2
Xaccess_guard VDD VSS gated_clk_buf pre_far access_request pre_off_ready PRECHARGE_OFF_GUARD
Xwrite_ready_nor VDD VSS we_bar wen_far write_ready_bar WRITE_READY_NOR
Xwrite_ready VDD VSS write_ready_bar write_ready PINV_write_ready
Xwordline_start VDD VSS access_request write_ready wordline_start WORDLINE_START_AND
Xwordline_setup_delay VDD VSS wordline_start access_settled WORDLINE_SETUP_DELAY
Xwordline_setup_gate VDD VSS access_request access_settled wordline_request WORDLINE_SETUP_AND
Xwl_en VDD VSS wordline_request read_done_bar wl_en WORDLINE_ENABLE_BUFFER
Xinv_wl_en_bar VDD VSS wl_en wl_en_bar PINV_wl_en_bar
Xdelaychain VDD VSS rbl rbl_delay REPLICA_DELAY_CHAIN
Xinv_rbl_delay_bar VDD VSS rbl_delay rbl_delay_bar PINV
Xread_done VDD VSS rbl_delay access_request we_bar read_done READ_DONE_AND
Xread_done_bar VDD VSS read_done read_done_bar PINV_read_done_bar
Xrwl_precharge_guard VDD VSS rwl rwl_pre_bar PINV_rwl_precharge
Xprecharge_guard_delay VDD VSS rwl_pre_bar rwl_pre_delayed PRECHARGE_GUARD_DELAY
Xprecharge_guard_ready VDD VSS rwl_pre_bar rwl_pre_delayed pre_ready PRECHARGE_GUARD_AND
Xwordline_busy_nand VDD VSS wl_en_bar pre_ready wordline_busy WORDLINE_BUSY_NAND
Xinv_wordline_idle VDD VSS wordline_busy wordline_idle PINV_wordline_idle
Xwrite_window_nor VDD VSS access_request wordline_busy write_window_bar WRITE_WINDOW_NOR
Xwrite_window_inv VDD VSS write_window_bar write_window PINV_write_window
Xw_en VDD VSS we write_window iso_ready w_en GUARDED_WRITE_AND
Xs_en VDD VSS read_done wordline_idle iso_ready s_en_unbuf AND3
Xs_en_buf VDD VSS s_en_unbuf s_en SENSE_ENABLE_BUFFER
Xwrite_prepare VDD VSS we access_request write_prepare WRITE_PREPARE_AND
Xisolation_request VDD VSS read_done write_prepare isolation_request_bar ISOLATION_REQUEST_NOR
Xsa_iso VDD VSS isolation_request_bar enables_off sa_iso_unbuf ISOLATION_NAND
Xsa_iso_buf VDD VSS sa_iso_unbuf sa_iso SENSE_ISOLATION_BUFFER
Xisolation_guard VDD VSS VDD iso_far isolation_observed iso_ready ISOLATION_OFF_GUARD
Xpre_unbuf VDD VSS clk_bar pre_ready enables_off PRE_UNBUF PNAND3
Xpre VDD VSS PRE_UNBUF PRE PRECHARGE_BUFFER
Xinv_s_en_bar VDD VSS s_en s_en_bar PINV_s_en_bar
Xenables_off_nor VDD VSS s_en w_en local_enables_off ENABLES_OFF_NOR
Xfar_enables_off VDD VSS sen_far wen_far far_enables_off FAR_ENABLES_OFF_NOR
Xenable_off_guard VDD VSS local_enables_off far_enables_off enables_off far_enables_ready ENABLE_OFF_GUARD
.ends TIME_CONTROL

.subckt DECODER_CASCADE VDD VSS A0 A1 WL0 WL1 WL2
.subckt DECODER3_8_ROWS0x1_8000000000000pp1 VDD VSS EN A0 A1 A2 WL0 WL1 WL2 WL3 WL4 WL5 WL6 WL7
.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV

.subckt AND3 VDD VSS A B C Z
.subckt PNAND3 VDD VSS A B C Z
Mpnand3_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_pmos3 Z C VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand3_nmos1 Z A net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand3_nmos2 net1 B net2 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand3_nmos3 net2 C VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND3

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV
XPNAND3 VDD VSS A B C zb_int PNAND3
XPINV VDD VSS zb_int Z PINV
.ends AND3

.subckt AND2 VDD VSS A B Z
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=9e-08
.ends PINV
RR_A_0 A A_seg0 100.0Ohm
CCg_A_0 A_seg0 0 0.001pF
RR_A_1 A_seg0 A_end 100.0Ohm
CCg_A_1 A_end 0 0.001pF
RR_B_0 B B_seg0 100.0Ohm
CCg_B_0 B_seg0 0 0.001pF
RR_B_1 B_seg0 B_end 100.0Ohm
CCg_B_1 B_end 0 0.001pF
RR_zb_int_0 zb_int zb_int_seg0 100.0Ohm
CCg_zb_int_0 zb_int_seg0 0 0.001pF
RR_zb_int_1 zb_int_seg0 zb_int_end 100.0Ohm
CCg_zb_int_1 zb_int_end 0 0.001pF
RR_Z_0 Z Z_seg0 100.0Ohm
CCg_Z_0 Z_seg0 0 0.001pF
RR_Z_1 Z_seg0 Z_end 100.0Ohm
CCg_Z_1 Z_end 0 0.001pF
XPNAND3 VDD VSS A_end B_end zb_int PNAND2
XPINV VDD VSS zb_int_end Z_end PINV
.ends AND2
Rwire_A0_line_0 A0 A0_line_tap0 0.1875Ohm
Rwire_A0_line_1 A0_line_tap0 A0_line_wire1 0.1875Ohm
Rwire_A0_line_2 A0_line_wire1 A0_line_tap1 0.1875Ohm
Rwire_A0_line_3 A0_line_tap1 A0_line_wire3 0.1875Ohm
Rwire_A0_line_4 A0_line_wire3 A0_line_tap2 0.1875Ohm
Rwire_A0_line_5 A0_line_tap2 A0_line_wire5 0.1875Ohm
Rwire_A0_line_6 A0_line_wire5 A0_line_tap3 0.1875Ohm
Rwire_A0_line_7 A0_line_tap3 A0_line_wire7 0.1875Ohm
Rwire_A0_line_8 A0_line_wire7 A0_line_tap4 0.1875Ohm
Rwire_A0_line_9 A0_line_tap4 A0_line_wire9 0.1875Ohm
Rwire_A0_line_10 A0_line_wire9 A0_line_tap5 0.1875Ohm
Rwire_A0_line_11 A0_line_tap5 A0_line_wire11 0.1875Ohm
Rwire_A0_line_12 A0_line_wire11 A0_line_tap6 0.1875Ohm
Rwire_A0_line_13 A0_line_tap6 A0_line_wire13 0.1875Ohm
Rwire_A0_line_14 A0_line_wire13 A0_line_tap7 0.1875Ohm
Rwire_A0_line_15 A0_line_tap7 A0_line_far 0.1875Ohm
Cwire_A0_line_0 A0 VSS 9.375e-18
Cwire_A0_line_1 A0_line_tap0 VSS 1.875e-17
Cwire_A0_line_2 A0_line_wire1 VSS 1.875e-17
Cwire_A0_line_3 A0_line_tap1 VSS 1.875e-17
Cwire_A0_line_4 A0_line_wire3 VSS 1.875e-17
Cwire_A0_line_5 A0_line_tap2 VSS 1.875e-17
Cwire_A0_line_6 A0_line_wire5 VSS 1.875e-17
Cwire_A0_line_7 A0_line_tap3 VSS 1.875e-17
Cwire_A0_line_8 A0_line_wire7 VSS 1.875e-17
Cwire_A0_line_9 A0_line_tap4 VSS 1.875e-17
Cwire_A0_line_10 A0_line_wire9 VSS 1.875e-17
Cwire_A0_line_11 A0_line_tap5 VSS 1.875e-17
Cwire_A0_line_12 A0_line_wire11 VSS 1.875e-17
Cwire_A0_line_13 A0_line_tap6 VSS 1.875e-17
Cwire_A0_line_14 A0_line_wire13 VSS 1.875e-17
Cwire_A0_line_15 A0_line_tap7 VSS 1.875e-17
Cwire_A0_line_16 A0_line_far VSS 9.375e-18
Rwire_A1_line_0 A1 A1_line_tap0 0.1875Ohm
Rwire_A1_line_1 A1_line_tap0 A1_line_wire1 0.1875Ohm
Rwire_A1_line_2 A1_line_wire1 A1_line_tap1 0.1875Ohm
Rwire_A1_line_3 A1_line_tap1 A1_line_wire3 0.1875Ohm
Rwire_A1_line_4 A1_line_wire3 A1_line_tap2 0.1875Ohm
Rwire_A1_line_5 A1_line_tap2 A1_line_wire5 0.1875Ohm
Rwire_A1_line_6 A1_line_wire5 A1_line_tap3 0.1875Ohm
Rwire_A1_line_7 A1_line_tap3 A1_line_wire7 0.1875Ohm
Rwire_A1_line_8 A1_line_wire7 A1_line_tap4 0.1875Ohm
Rwire_A1_line_9 A1_line_tap4 A1_line_wire9 0.1875Ohm
Rwire_A1_line_10 A1_line_wire9 A1_line_tap5 0.1875Ohm
Rwire_A1_line_11 A1_line_tap5 A1_line_wire11 0.1875Ohm
Rwire_A1_line_12 A1_line_wire11 A1_line_tap6 0.1875Ohm
Rwire_A1_line_13 A1_line_tap6 A1_line_wire13 0.1875Ohm
Rwire_A1_line_14 A1_line_wire13 A1_line_tap7 0.1875Ohm
Rwire_A1_line_15 A1_line_tap7 A1_line_far 0.1875Ohm
Cwire_A1_line_0 A1 VSS 9.375e-18
Cwire_A1_line_1 A1_line_tap0 VSS 1.875e-17
Cwire_A1_line_2 A1_line_wire1 VSS 1.875e-17
Cwire_A1_line_3 A1_line_tap1 VSS 1.875e-17
Cwire_A1_line_4 A1_line_wire3 VSS 1.875e-17
Cwire_A1_line_5 A1_line_tap2 VSS 1.875e-17
Cwire_A1_line_6 A1_line_wire5 VSS 1.875e-17
Cwire_A1_line_7 A1_line_tap3 VSS 1.875e-17
Cwire_A1_line_8 A1_line_wire7 VSS 1.875e-17
Cwire_A1_line_9 A1_line_tap4 VSS 1.875e-17
Cwire_A1_line_10 A1_line_wire9 VSS 1.875e-17
Cwire_A1_line_11 A1_line_tap5 VSS 1.875e-17
Cwire_A1_line_12 A1_line_wire11 VSS 1.875e-17
Cwire_A1_line_13 A1_line_tap6 VSS 1.875e-17
Cwire_A1_line_14 A1_line_wire13 VSS 1.875e-17
Cwire_A1_line_15 A1_line_tap7 VSS 1.875e-17
Cwire_A1_line_16 A1_line_far VSS 9.375e-18
Rwire_A2_line_0 A2 A2_line_tap0 0.1875Ohm
Rwire_A2_line_1 A2_line_tap0 A2_line_wire1 0.1875Ohm
Rwire_A2_line_2 A2_line_wire1 A2_line_tap1 0.1875Ohm
Rwire_A2_line_3 A2_line_tap1 A2_line_wire3 0.1875Ohm
Rwire_A2_line_4 A2_line_wire3 A2_line_tap2 0.1875Ohm
Rwire_A2_line_5 A2_line_tap2 A2_line_wire5 0.1875Ohm
Rwire_A2_line_6 A2_line_wire5 A2_line_tap3 0.1875Ohm
Rwire_A2_line_7 A2_line_tap3 A2_line_wire7 0.1875Ohm
Rwire_A2_line_8 A2_line_wire7 A2_line_tap4 0.1875Ohm
Rwire_A2_line_9 A2_line_tap4 A2_line_wire9 0.1875Ohm
Rwire_A2_line_10 A2_line_wire9 A2_line_tap5 0.1875Ohm
Rwire_A2_line_11 A2_line_tap5 A2_line_wire11 0.1875Ohm
Rwire_A2_line_12 A2_line_wire11 A2_line_tap6 0.1875Ohm
Rwire_A2_line_13 A2_line_tap6 A2_line_wire13 0.1875Ohm
Rwire_A2_line_14 A2_line_wire13 A2_line_tap7 0.1875Ohm
Rwire_A2_line_15 A2_line_tap7 A2_line_far 0.1875Ohm
Cwire_A2_line_0 A2 VSS 9.375e-18
Cwire_A2_line_1 A2_line_tap0 VSS 1.875e-17
Cwire_A2_line_2 A2_line_wire1 VSS 1.875e-17
Cwire_A2_line_3 A2_line_tap1 VSS 1.875e-17
Cwire_A2_line_4 A2_line_wire3 VSS 1.875e-17
Cwire_A2_line_5 A2_line_tap2 VSS 1.875e-17
Cwire_A2_line_6 A2_line_wire5 VSS 1.875e-17
Cwire_A2_line_7 A2_line_tap3 VSS 1.875e-17
Cwire_A2_line_8 A2_line_wire7 VSS 1.875e-17
Cwire_A2_line_9 A2_line_tap4 VSS 1.875e-17
Cwire_A2_line_10 A2_line_wire9 VSS 1.875e-17
Cwire_A2_line_11 A2_line_tap5 VSS 1.875e-17
Cwire_A2_line_12 A2_line_wire11 VSS 1.875e-17
Cwire_A2_line_13 A2_line_tap6 VSS 1.875e-17
Cwire_A2_line_14 A2_line_wire13 VSS 1.875e-17
Cwire_A2_line_15 A2_line_tap7 VSS 1.875e-17
Cwire_A2_line_16 A2_line_far VSS 9.375e-18
Rwire_A0b_line_0 A0b A0b_line_tap0 0.1875Ohm
Rwire_A0b_line_1 A0b_line_tap0 A0b_line_wire1 0.1875Ohm
Rwire_A0b_line_2 A0b_line_wire1 A0b_line_tap1 0.1875Ohm
Rwire_A0b_line_3 A0b_line_tap1 A0b_line_wire3 0.1875Ohm
Rwire_A0b_line_4 A0b_line_wire3 A0b_line_tap2 0.1875Ohm
Rwire_A0b_line_5 A0b_line_tap2 A0b_line_wire5 0.1875Ohm
Rwire_A0b_line_6 A0b_line_wire5 A0b_line_tap3 0.1875Ohm
Rwire_A0b_line_7 A0b_line_tap3 A0b_line_wire7 0.1875Ohm
Rwire_A0b_line_8 A0b_line_wire7 A0b_line_tap4 0.1875Ohm
Rwire_A0b_line_9 A0b_line_tap4 A0b_line_wire9 0.1875Ohm
Rwire_A0b_line_10 A0b_line_wire9 A0b_line_tap5 0.1875Ohm
Rwire_A0b_line_11 A0b_line_tap5 A0b_line_wire11 0.1875Ohm
Rwire_A0b_line_12 A0b_line_wire11 A0b_line_tap6 0.1875Ohm
Rwire_A0b_line_13 A0b_line_tap6 A0b_line_wire13 0.1875Ohm
Rwire_A0b_line_14 A0b_line_wire13 A0b_line_tap7 0.1875Ohm
Rwire_A0b_line_15 A0b_line_tap7 A0b_line_far 0.1875Ohm
Cwire_A0b_line_0 A0b VSS 9.375e-18
Cwire_A0b_line_1 A0b_line_tap0 VSS 1.875e-17
Cwire_A0b_line_2 A0b_line_wire1 VSS 1.875e-17
Cwire_A0b_line_3 A0b_line_tap1 VSS 1.875e-17
Cwire_A0b_line_4 A0b_line_wire3 VSS 1.875e-17
Cwire_A0b_line_5 A0b_line_tap2 VSS 1.875e-17
Cwire_A0b_line_6 A0b_line_wire5 VSS 1.875e-17
Cwire_A0b_line_7 A0b_line_tap3 VSS 1.875e-17
Cwire_A0b_line_8 A0b_line_wire7 VSS 1.875e-17
Cwire_A0b_line_9 A0b_line_tap4 VSS 1.875e-17
Cwire_A0b_line_10 A0b_line_wire9 VSS 1.875e-17
Cwire_A0b_line_11 A0b_line_tap5 VSS 1.875e-17
Cwire_A0b_line_12 A0b_line_wire11 VSS 1.875e-17
Cwire_A0b_line_13 A0b_line_tap6 VSS 1.875e-17
Cwire_A0b_line_14 A0b_line_wire13 VSS 1.875e-17
Cwire_A0b_line_15 A0b_line_tap7 VSS 1.875e-17
Cwire_A0b_line_16 A0b_line_far VSS 9.375e-18
Rwire_A1b_line_0 A1b A1b_line_tap0 0.1875Ohm
Rwire_A1b_line_1 A1b_line_tap0 A1b_line_wire1 0.1875Ohm
Rwire_A1b_line_2 A1b_line_wire1 A1b_line_tap1 0.1875Ohm
Rwire_A1b_line_3 A1b_line_tap1 A1b_line_wire3 0.1875Ohm
Rwire_A1b_line_4 A1b_line_wire3 A1b_line_tap2 0.1875Ohm
Rwire_A1b_line_5 A1b_line_tap2 A1b_line_wire5 0.1875Ohm
Rwire_A1b_line_6 A1b_line_wire5 A1b_line_tap3 0.1875Ohm
Rwire_A1b_line_7 A1b_line_tap3 A1b_line_wire7 0.1875Ohm
Rwire_A1b_line_8 A1b_line_wire7 A1b_line_tap4 0.1875Ohm
Rwire_A1b_line_9 A1b_line_tap4 A1b_line_wire9 0.1875Ohm
Rwire_A1b_line_10 A1b_line_wire9 A1b_line_tap5 0.1875Ohm
Rwire_A1b_line_11 A1b_line_tap5 A1b_line_wire11 0.1875Ohm
Rwire_A1b_line_12 A1b_line_wire11 A1b_line_tap6 0.1875Ohm
Rwire_A1b_line_13 A1b_line_tap6 A1b_line_wire13 0.1875Ohm
Rwire_A1b_line_14 A1b_line_wire13 A1b_line_tap7 0.1875Ohm
Rwire_A1b_line_15 A1b_line_tap7 A1b_line_far 0.1875Ohm
Cwire_A1b_line_0 A1b VSS 9.375e-18
Cwire_A1b_line_1 A1b_line_tap0 VSS 1.875e-17
Cwire_A1b_line_2 A1b_line_wire1 VSS 1.875e-17
Cwire_A1b_line_3 A1b_line_tap1 VSS 1.875e-17
Cwire_A1b_line_4 A1b_line_wire3 VSS 1.875e-17
Cwire_A1b_line_5 A1b_line_tap2 VSS 1.875e-17
Cwire_A1b_line_6 A1b_line_wire5 VSS 1.875e-17
Cwire_A1b_line_7 A1b_line_tap3 VSS 1.875e-17
Cwire_A1b_line_8 A1b_line_wire7 VSS 1.875e-17
Cwire_A1b_line_9 A1b_line_tap4 VSS 1.875e-17
Cwire_A1b_line_10 A1b_line_wire9 VSS 1.875e-17
Cwire_A1b_line_11 A1b_line_tap5 VSS 1.875e-17
Cwire_A1b_line_12 A1b_line_wire11 VSS 1.875e-17
Cwire_A1b_line_13 A1b_line_tap6 VSS 1.875e-17
Cwire_A1b_line_14 A1b_line_wire13 VSS 1.875e-17
Cwire_A1b_line_15 A1b_line_tap7 VSS 1.875e-17
Cwire_A1b_line_16 A1b_line_far VSS 9.375e-18
Rwire_A2b_line_0 A2b A2b_line_tap0 0.1875Ohm
Rwire_A2b_line_1 A2b_line_tap0 A2b_line_wire1 0.1875Ohm
Rwire_A2b_line_2 A2b_line_wire1 A2b_line_tap1 0.1875Ohm
Rwire_A2b_line_3 A2b_line_tap1 A2b_line_wire3 0.1875Ohm
Rwire_A2b_line_4 A2b_line_wire3 A2b_line_tap2 0.1875Ohm
Rwire_A2b_line_5 A2b_line_tap2 A2b_line_wire5 0.1875Ohm
Rwire_A2b_line_6 A2b_line_wire5 A2b_line_tap3 0.1875Ohm
Rwire_A2b_line_7 A2b_line_tap3 A2b_line_wire7 0.1875Ohm
Rwire_A2b_line_8 A2b_line_wire7 A2b_line_tap4 0.1875Ohm
Rwire_A2b_line_9 A2b_line_tap4 A2b_line_wire9 0.1875Ohm
Rwire_A2b_line_10 A2b_line_wire9 A2b_line_tap5 0.1875Ohm
Rwire_A2b_line_11 A2b_line_tap5 A2b_line_wire11 0.1875Ohm
Rwire_A2b_line_12 A2b_line_wire11 A2b_line_tap6 0.1875Ohm
Rwire_A2b_line_13 A2b_line_tap6 A2b_line_wire13 0.1875Ohm
Rwire_A2b_line_14 A2b_line_wire13 A2b_line_tap7 0.1875Ohm
Rwire_A2b_line_15 A2b_line_tap7 A2b_line_far 0.1875Ohm
Cwire_A2b_line_0 A2b VSS 9.375e-18
Cwire_A2b_line_1 A2b_line_tap0 VSS 1.875e-17
Cwire_A2b_line_2 A2b_line_wire1 VSS 1.875e-17
Cwire_A2b_line_3 A2b_line_tap1 VSS 1.875e-17
Cwire_A2b_line_4 A2b_line_wire3 VSS 1.875e-17
Cwire_A2b_line_5 A2b_line_tap2 VSS 1.875e-17
Cwire_A2b_line_6 A2b_line_wire5 VSS 1.875e-17
Cwire_A2b_line_7 A2b_line_tap3 VSS 1.875e-17
Cwire_A2b_line_8 A2b_line_wire7 VSS 1.875e-17
Cwire_A2b_line_9 A2b_line_tap4 VSS 1.875e-17
Cwire_A2b_line_10 A2b_line_wire9 VSS 1.875e-17
Cwire_A2b_line_11 A2b_line_tap5 VSS 1.875e-17
Cwire_A2b_line_12 A2b_line_wire11 VSS 1.875e-17
Cwire_A2b_line_13 A2b_line_tap6 VSS 1.875e-17
Cwire_A2b_line_14 A2b_line_wire13 VSS 1.875e-17
Cwire_A2b_line_15 A2b_line_tap7 VSS 1.875e-17
Cwire_A2b_line_16 A2b_line_far VSS 9.375e-18
Rwire_EN_line_0 EN EN_line_tap0 0.1875Ohm
Rwire_EN_line_1 EN_line_tap0 EN_line_wire1 0.1875Ohm
Rwire_EN_line_2 EN_line_wire1 EN_line_tap1 0.1875Ohm
Rwire_EN_line_3 EN_line_tap1 EN_line_wire3 0.1875Ohm
Rwire_EN_line_4 EN_line_wire3 EN_line_tap2 0.1875Ohm
Rwire_EN_line_5 EN_line_tap2 EN_line_wire5 0.1875Ohm
Rwire_EN_line_6 EN_line_wire5 EN_line_tap3 0.1875Ohm
Rwire_EN_line_7 EN_line_tap3 EN_line_wire7 0.1875Ohm
Rwire_EN_line_8 EN_line_wire7 EN_line_tap4 0.1875Ohm
Rwire_EN_line_9 EN_line_tap4 EN_line_wire9 0.1875Ohm
Rwire_EN_line_10 EN_line_wire9 EN_line_tap5 0.1875Ohm
Rwire_EN_line_11 EN_line_tap5 EN_line_wire11 0.1875Ohm
Rwire_EN_line_12 EN_line_wire11 EN_line_tap6 0.1875Ohm
Rwire_EN_line_13 EN_line_tap6 EN_line_wire13 0.1875Ohm
Rwire_EN_line_14 EN_line_wire13 EN_line_tap7 0.1875Ohm
Rwire_EN_line_15 EN_line_tap7 EN_line_far 0.1875Ohm
Cwire_EN_line_0 EN VSS 9.375e-18
Cwire_EN_line_1 EN_line_tap0 VSS 1.875e-17
Cwire_EN_line_2 EN_line_wire1 VSS 1.875e-17
Cwire_EN_line_3 EN_line_tap1 VSS 1.875e-17
Cwire_EN_line_4 EN_line_wire3 VSS 1.875e-17
Cwire_EN_line_5 EN_line_tap2 VSS 1.875e-17
Cwire_EN_line_6 EN_line_wire5 VSS 1.875e-17
Cwire_EN_line_7 EN_line_tap3 VSS 1.875e-17
Cwire_EN_line_8 EN_line_wire7 VSS 1.875e-17
Cwire_EN_line_9 EN_line_tap4 VSS 1.875e-17
Cwire_EN_line_10 EN_line_wire9 VSS 1.875e-17
Cwire_EN_line_11 EN_line_tap5 VSS 1.875e-17
Cwire_EN_line_12 EN_line_wire11 VSS 1.875e-17
Cwire_EN_line_13 EN_line_tap6 VSS 1.875e-17
Cwire_EN_line_14 EN_line_wire13 VSS 1.875e-17
Cwire_EN_line_15 EN_line_tap7 VSS 1.875e-17
Cwire_EN_line_16 EN_line_far VSS 9.375e-18
XINV_A1 VDD VSS A0 A0b PINV
XINV_A2 VDD VSS A1 A1b PINV
XINV_A3 VDD VSS A2 A2b PINV
XAND0 VDD VSS A0b_line_tap0 A1b_line_tap0 A2b_line_tap0 WL0_pre AND3
XAND_EN0 VDD VSS WL0_pre EN_line_tap0 WL0 AND2
XAND1 VDD VSS A0b_line_tap1 A1b_line_tap1 A2_line_tap1 WL1_pre AND3
XAND_EN1 VDD VSS WL1_pre EN_line_tap1 WL1 AND2
XAND2 VDD VSS A0b_line_tap2 A1_line_tap2 A2b_line_tap2 WL2_pre AND3
XAND_EN2 VDD VSS WL2_pre EN_line_tap2 WL2 AND2
XAND3 VDD VSS A0b_line_tap3 A1_line_tap3 A2_line_tap3 WL3_pre AND3
XAND_EN3 VDD VSS WL3_pre EN_line_tap3 WL3 AND2
XAND4 VDD VSS A0_line_tap4 A1b_line_tap4 A2b_line_tap4 WL4_pre AND3
XAND_EN4 VDD VSS WL4_pre EN_line_tap4 WL4 AND2
XAND5 VDD VSS A0_line_tap5 A1b_line_tap5 A2_line_tap5 WL5_pre AND3
XAND_EN5 VDD VSS WL5_pre EN_line_tap5 WL5 AND2
XAND6 VDD VSS A0_line_tap6 A1_line_tap6 A2b_line_tap6 WL6_pre AND3
XAND_EN6 VDD VSS WL6_pre EN_line_tap6 WL6 AND2
XAND7 VDD VSS A0_line_tap7 A1_line_tap7 A2_line_tap7 WL7_pre AND3
XAND_EN7 VDD VSS WL7_pre EN_line_tap7 WL7 AND2
.ends DECODER3_8_ROWS0x1_8000000000000pp1
Rwire_A0_line_0 A0 A0_line_tap0 1.5Ohm
Rwire_A0_line_1 A0_line_tap0 A0_line_far 1.5Ohm
Cwire_A0_line_0 A0 VSS 7.5e-17
Cwire_A0_line_1 A0_line_tap0 VSS 1.5e-16
Cwire_A0_line_2 A0_line_far VSS 7.5e-17
Rwire_A1_line_0 A1 A1_line_tap0 1.5Ohm
Rwire_A1_line_1 A1_line_tap0 A1_line_far 1.5Ohm
Cwire_A1_line_0 A1 VSS 7.5e-17
Cwire_A1_line_1 A1_line_tap0 VSS 1.5e-16
Cwire_A1_line_2 A1_line_far VSS 7.5e-17
XDEC_0_0 VDD VSS VDD VSS A1_line_tap0 A0_line_tap0 WL0 WL1 WL2 NC_0_0_3 NC_0_0_4 NC_0_0_5 NC_0_0_6 NC_0_0_7 DECODER3_8_ROWS0x1_8000000000000pp1
.ends DECODER_CASCADE

.subckt PRECHARGE VDD ENB BL BLB
RR_BL_0 BL BL_seg0 100.0Ohm
CCg_BL_0 BL_seg0 0 0.001pF
RR_BL_1 BL_seg0 BL_end 100.0Ohm
CCg_BL_1 BL_end 0 0.001pF
RR_BLB_0 BLB BLB_seg0 100.0Ohm
CCg_BLB_0 BLB_seg0 0 0.001pF
RR_BLB_1 BLB_seg0 BLB_end 100.0Ohm
CCg_BLB_1 BLB_end 0 0.001pF
RR_ENB_0 ENB ENB_end 100.0Ohm
CCg_ENB_0 ENB_end 0 0.001pF
M1 BL_end ENB_end VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
M2 BLB_end ENB_end VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
M3 BL_end ENB_end BLB_end VDD PMOS_VTG l=5e-08 w=2.7e-07
.ends PRECHARGE

.subckt SENSEAMP VDD VSS EN ISO IN INB Q QB
RR_EN_0 EN EN_seg0 100.0Ohm
CCg_EN_0 EN_seg0 0 0.001pF
RR_EN_1 EN_seg0 EN_end 100.0Ohm
CCg_EN_1 EN_end 0 0.001pF
RR_ISO_0 ISO ISO_seg0 100.0Ohm
CCg_ISO_0 ISO_seg0 0 0.001pF
RR_ISO_1 ISO_seg0 ISO_end 100.0Ohm
CCg_ISO_1 ISO_end 0 0.001pF
RR_IN_0 IN IN_seg0 100.0Ohm
CCg_IN_0 IN_seg0 0 0.001pF
RR_IN_1 IN_seg0 IN_end 100.0Ohm
CCg_IN_1 IN_end 0 0.001pF
RR_INB_0 INB INB_seg0 100.0Ohm
CCg_INB_0 INB_seg0 0 0.001pF
RR_INB_1 INB_seg0 INB_end 100.0Ohm
CCg_INB_1 INB_end 0 0.001pF
RR_Q_0 Q Q_seg0 100.0Ohm
CCg_Q_0 Q_seg0 0 0.001pF
RR_Q_1 Q_seg0 Q_end 100.0Ohm
CCg_Q_1 Q_end 0 0.001pF
RR_QB_0 QB QB_seg0 100.0Ohm
CCg_QB_0 QB_seg0 0 0.001pF
RR_QB_1 QB_seg0 QB_end 100.0Ohm
CCg_QB_1 QB_end 0 0.001pF
RR_net1_0 net1 net1_end 100.0Ohm
CCg_net1_0 net1_end 0 0.001pF
M1 Q QB_end net1 VSS NMOS_VTG l=5e-08 w=2.7e-07
M2 Q QB_end VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
M3 QB Q_end net1 VSS NMOS_VTG l=5e-08 w=2.7e-07
M4 QB Q_end VDD VDD PMOS_VTG l=5e-08 w=5.4e-07
M5 Q ISO_end IN_end VDD PMOS_VTG l=5e-08 w=7.2e-07
M6 QB ISO_end INB_end VDD PMOS_VTG l=5e-08 w=7.2e-07
M7 net1_end EN_end VSS VSS NMOS_VTG l=5e-08 w=2.7e-07
.ends SENSEAMP

.subckt WRITEDRIVER VDD VSS EN DIN BL BLB
RR_DIN_0 DIN DIN_end 100.0Ohm
CCg_DIN_0 DIN_end 0 0.001pF
RR_DINB_0 DINB DINB_end 100.0Ohm
CCg_DINB_0 DINB_end 0 0.001pF
RR_BL_0 BL BL_seg0 100.0Ohm
CCg_BL_0 BL_seg0 0 0.001pF
RR_BL_1 BL_seg0 BL_end 100.0Ohm
CCg_BL_1 BL_end 0 0.001pF
RR_BLB_0 BLB BLB_seg0 100.0Ohm
CCg_BLB_0 BLB_seg0 0 0.001pF
RR_BLB_1 BLB_seg0 BLB_end 100.0Ohm
CCg_BLB_1 BLB_end 0 0.001pF
RR_EN_0 EN EN_end 100.0Ohm
CCg_EN_0 EN_end 0 0.001pF
RR_ENB_0 ENB ENB_end 100.0Ohm
CCg_ENB_0 ENB_end 0 0.001pF
M1 DINB DIN_end VDD VDD PMOS_VTG l=5e-08 w=3.6e-07
M2 DINB DIN_end VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
M3 ENB EN_end VDD VDD PMOS_VTG l=5e-08 w=3.6e-07
M4 ENB EN_end VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
M5 int1 DINB_end VDD VDD PMOS_VTG l=5e-08 w=7.2e-07
M6 BL_end ENB_end int1 VDD PMOS_VTG l=5e-08 w=7.2e-07
M7 BL_end EN_end int2 VSS NMOS_VTG l=5e-08 w=3.6e-07
M8 int2 DINB_end VSS VSS NMOS_VTG l=5e-08 w=3.6e-07
M9 int3 DIN_end VDD VDD PMOS_VTG l=5e-08 w=7.2e-07
M10 BLB_end ENB_end int3 VDD PMOS_VTG l=5e-08 w=7.2e-07
M11 BLB_end EN_end int4 VSS NMOS_VTG l=5e-08 w=3.6e-07
M12 int4 DIN_end VSS VSS NMOS_VTG l=5e-08 w=3.6e-07
.ends WRITEDRIVER

.subckt D_LATCH VDD VSS D EN Q QB
.subckt PNAND2 VDD VSS A B Z
Mpnand2_pmos1 Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_pmos2 Z B VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpnand2_nmos1 Z B net1 VSS NMOS_VTG l=5e-08 w=1.8e-07
Mpnand2_nmos2 net1 A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PNAND2

.subckt PINV VDD VSS A Z
Mpinv_pmos Z A VDD VDD PMOS_VTG l=5e-08 w=2.7e-07
Mpinv_nmos Z A VSS VSS NMOS_VTG l=5e-08 w=1.8e-07
.ends PINV
XINV1 VDD VSS D DB PINV
XNAND1 VDD VSS D EN INT1 PNAND2
XNAND2 VDD VSS DB EN INT2 PNAND2
XNAND3 VDD VSS INT1 QB Q PNAND2
XNAND4 VDD VSS INT2 Q QB PNAND2
.ends D_LATCH
VVDD VDD VSS 1.0V
VVSS VSS 0 0V
XSRAM_6T_CORE_3x2 VDD VSS BL0 BL1 BLB0 BLB1 WL0 WL1 WL2 SRAM_6T_CORE_3x2
Rwire_PRE_line_0 PRE PRE_line_tap0 0.5Ohm
Rwire_PRE_line_1 PRE_line_tap0 PRE_line_wire1 0.5Ohm
Rwire_PRE_line_2 PRE_line_wire1 PRE_line_tap1 0.5Ohm
Rwire_PRE_line_3 PRE_line_tap1 PRE_line_far 0.5Ohm
Cwire_PRE_line_0 PRE VSS 2.4999999999999996e-17
Cwire_PRE_line_1 PRE_line_tap0 VSS 4.999999999999999e-17
Cwire_PRE_line_2 PRE_line_wire1 VSS 4.999999999999999e-17
Cwire_PRE_line_3 PRE_line_tap1 VSS 4.999999999999999e-17
Cwire_PRE_line_4 PRE_line_far VSS 2.4999999999999996e-17
Rwire_w_en_line_0 w_en w_en_line_tap0 0.5Ohm
Rwire_w_en_line_1 w_en_line_tap0 w_en_line_wire1 0.5Ohm
Rwire_w_en_line_2 w_en_line_wire1 w_en_line_tap1 0.5Ohm
Rwire_w_en_line_3 w_en_line_tap1 w_en_line_far 0.5Ohm
Cwire_w_en_line_0 w_en VSS 2.4999999999999996e-17
Cwire_w_en_line_1 w_en_line_tap0 VSS 4.999999999999999e-17
Cwire_w_en_line_2 w_en_line_wire1 VSS 4.999999999999999e-17
Cwire_w_en_line_3 w_en_line_tap1 VSS 4.999999999999999e-17
Cwire_w_en_line_4 w_en_line_far VSS 2.4999999999999996e-17
Rwire_s_en_line_0 s_en s_en_line_tap0 0.5Ohm
Rwire_s_en_line_1 s_en_line_tap0 s_en_line_wire1 0.5Ohm
Rwire_s_en_line_2 s_en_line_wire1 s_en_line_tap1 0.5Ohm
Rwire_s_en_line_3 s_en_line_tap1 s_en_line_far 0.5Ohm
Cwire_s_en_line_0 s_en VSS 2.4999999999999996e-17
Cwire_s_en_line_1 s_en_line_tap0 VSS 4.999999999999999e-17
Cwire_s_en_line_2 s_en_line_wire1 VSS 4.999999999999999e-17
Cwire_s_en_line_3 s_en_line_tap1 VSS 4.999999999999999e-17
Cwire_s_en_line_4 s_en_line_far VSS 2.4999999999999996e-17
Rwire_sa_iso_line_0 sa_iso sa_iso_line_tap0 0.5Ohm
Rwire_sa_iso_line_1 sa_iso_line_tap0 sa_iso_line_wire1 0.5Ohm
Rwire_sa_iso_line_2 sa_iso_line_wire1 sa_iso_line_tap1 0.5Ohm
Rwire_sa_iso_line_3 sa_iso_line_tap1 sa_iso_line_far 0.5Ohm
Cwire_sa_iso_line_0 sa_iso VSS 2.4999999999999996e-17
Cwire_sa_iso_line_1 sa_iso_line_tap0 VSS 4.999999999999999e-17
Cwire_sa_iso_line_2 sa_iso_line_wire1 VSS 4.999999999999999e-17
Cwire_sa_iso_line_3 sa_iso_line_tap1 VSS 4.999999999999999e-17
Cwire_sa_iso_line_4 sa_iso_line_far VSS 2.4999999999999996e-17
Rwire_wl_en_line_0 wl_en wl_en_line_tap0 0.5Ohm
Rwire_wl_en_line_1 wl_en_line_tap0 wl_en_line_wire1 0.5Ohm
Rwire_wl_en_line_2 wl_en_line_wire1 wl_en_line_tap1 0.5Ohm
Rwire_wl_en_line_3 wl_en_line_tap1 wl_en_line_wire3 0.5Ohm
Rwire_wl_en_line_4 wl_en_line_wire3 wl_en_line_tap2 0.5Ohm
Rwire_wl_en_line_5 wl_en_line_tap2 wl_en_line_far 0.5Ohm
Cwire_wl_en_line_0 wl_en VSS 2.4999999999999996e-17
Cwire_wl_en_line_1 wl_en_line_tap0 VSS 4.999999999999999e-17
Cwire_wl_en_line_2 wl_en_line_wire1 VSS 4.999999999999999e-17
Cwire_wl_en_line_3 wl_en_line_tap1 VSS 4.999999999999999e-17
Cwire_wl_en_line_4 wl_en_line_wire3 VSS 4.999999999999999e-17
Cwire_wl_en_line_5 wl_en_line_tap2 VSS 4.999999999999999e-17
Cwire_wl_en_line_6 wl_en_line_far VSS 2.4999999999999996e-17
Rwire_BL0_periph_0 BL0 BL0_periph_tap0 0.5Ohm
Rwire_BL0_periph_1 BL0_periph_tap0 BL0_periph_wire1 0.5Ohm
Rwire_BL0_periph_2 BL0_periph_wire1 BL0_periph_tap1 0.5Ohm
Rwire_BL0_periph_3 BL0_periph_tap1 BL0_periph_wire3 0.5Ohm
Rwire_BL0_periph_4 BL0_periph_wire3 BL0_periph_tap2 0.5Ohm
Rwire_BL0_periph_5 BL0_periph_tap2 BL0_periph_far 0.5Ohm
Cwire_BL0_periph_0 BL0 VSS 2.4999999999999996e-17
Cwire_BL0_periph_1 BL0_periph_tap0 VSS 4.999999999999999e-17
Cwire_BL0_periph_2 BL0_periph_wire1 VSS 4.999999999999999e-17
Cwire_BL0_periph_3 BL0_periph_tap1 VSS 4.999999999999999e-17
Cwire_BL0_periph_4 BL0_periph_wire3 VSS 4.999999999999999e-17
Cwire_BL0_periph_5 BL0_periph_tap2 VSS 4.999999999999999e-17
Cwire_BL0_periph_6 BL0_periph_far VSS 2.4999999999999996e-17
Rwire_BLB0_periph_0 BLB0 BLB0_periph_tap0 0.5Ohm
Rwire_BLB0_periph_1 BLB0_periph_tap0 BLB0_periph_wire1 0.5Ohm
Rwire_BLB0_periph_2 BLB0_periph_wire1 BLB0_periph_tap1 0.5Ohm
Rwire_BLB0_periph_3 BLB0_periph_tap1 BLB0_periph_wire3 0.5Ohm
Rwire_BLB0_periph_4 BLB0_periph_wire3 BLB0_periph_tap2 0.5Ohm
Rwire_BLB0_periph_5 BLB0_periph_tap2 BLB0_periph_far 0.5Ohm
Cwire_BLB0_periph_0 BLB0 VSS 2.4999999999999996e-17
Cwire_BLB0_periph_1 BLB0_periph_tap0 VSS 4.999999999999999e-17
Cwire_BLB0_periph_2 BLB0_periph_wire1 VSS 4.999999999999999e-17
Cwire_BLB0_periph_3 BLB0_periph_tap1 VSS 4.999999999999999e-17
Cwire_BLB0_periph_4 BLB0_periph_wire3 VSS 4.999999999999999e-17
Cwire_BLB0_periph_5 BLB0_periph_tap2 VSS 4.999999999999999e-17
Cwire_BLB0_periph_6 BLB0_periph_far VSS 2.4999999999999996e-17
Rwire_BL1_periph_0 BL1 BL1_periph_tap0 0.5Ohm
Rwire_BL1_periph_1 BL1_periph_tap0 BL1_periph_wire1 0.5Ohm
Rwire_BL1_periph_2 BL1_periph_wire1 BL1_periph_tap1 0.5Ohm
Rwire_BL1_periph_3 BL1_periph_tap1 BL1_periph_wire3 0.5Ohm
Rwire_BL1_periph_4 BL1_periph_wire3 BL1_periph_tap2 0.5Ohm
Rwire_BL1_periph_5 BL1_periph_tap2 BL1_periph_far 0.5Ohm
Cwire_BL1_periph_0 BL1 VSS 2.4999999999999996e-17
Cwire_BL1_periph_1 BL1_periph_tap0 VSS 4.999999999999999e-17
Cwire_BL1_periph_2 BL1_periph_wire1 VSS 4.999999999999999e-17
Cwire_BL1_periph_3 BL1_periph_tap1 VSS 4.999999999999999e-17
Cwire_BL1_periph_4 BL1_periph_wire3 VSS 4.999999999999999e-17
Cwire_BL1_periph_5 BL1_periph_tap2 VSS 4.999999999999999e-17
Cwire_BL1_periph_6 BL1_periph_far VSS 2.4999999999999996e-17
Rwire_BLB1_periph_0 BLB1 BLB1_periph_tap0 0.5Ohm
Rwire_BLB1_periph_1 BLB1_periph_tap0 BLB1_periph_wire1 0.5Ohm
Rwire_BLB1_periph_2 BLB1_periph_wire1 BLB1_periph_tap1 0.5Ohm
Rwire_BLB1_periph_3 BLB1_periph_tap1 BLB1_periph_wire3 0.5Ohm
Rwire_BLB1_periph_4 BLB1_periph_wire3 BLB1_periph_tap2 0.5Ohm
Rwire_BLB1_periph_5 BLB1_periph_tap2 BLB1_periph_far 0.5Ohm
Cwire_BLB1_periph_0 BLB1 VSS 2.4999999999999996e-17
Cwire_BLB1_periph_1 BLB1_periph_tap0 VSS 4.999999999999999e-17
Cwire_BLB1_periph_2 BLB1_periph_wire1 VSS 4.999999999999999e-17
Cwire_BLB1_periph_3 BLB1_periph_tap1 VSS 4.999999999999999e-17
Cwire_BLB1_periph_4 BLB1_periph_wire3 VSS 4.999999999999999e-17
Cwire_BLB1_periph_5 BLB1_periph_tap2 VSS 4.999999999999999e-17
Cwire_BLB1_periph_6 BLB1_periph_far VSS 2.4999999999999996e-17
Rwire_RBL_periph_0 RBL RBL_periph_tap0 0.5Ohm
Rwire_RBL_periph_1 RBL_periph_tap0 RBL_periph_wire1 0.5Ohm
Rwire_RBL_periph_2 RBL_periph_wire1 RBL_periph_tap1 0.5Ohm
Rwire_RBL_periph_3 RBL_periph_tap1 RBL_periph_wire3 0.5Ohm
Rwire_RBL_periph_4 RBL_periph_wire3 RBL_periph_tap2 0.5Ohm
Rwire_RBL_periph_5 RBL_periph_tap2 RBL_periph_far 0.5Ohm
Cwire_RBL_periph_0 RBL VSS 2.4999999999999996e-17
Cwire_RBL_periph_1 RBL_periph_tap0 VSS 4.999999999999999e-17
Cwire_RBL_periph_2 RBL_periph_wire1 VSS 4.999999999999999e-17
Cwire_RBL_periph_3 RBL_periph_tap1 VSS 4.999999999999999e-17
Cwire_RBL_periph_4 RBL_periph_wire3 VSS 4.999999999999999e-17
Cwire_RBL_periph_5 RBL_periph_tap2 VSS 4.999999999999999e-17
Cwire_RBL_periph_6 RBL_periph_far VSS 2.4999999999999996e-17
Rwire_RBLB_periph_0 RBLB RBLB_periph_tap0 0.5Ohm
Rwire_RBLB_periph_1 RBLB_periph_tap0 RBLB_periph_wire1 0.5Ohm
Rwire_RBLB_periph_2 RBLB_periph_wire1 RBLB_periph_tap1 0.5Ohm
Rwire_RBLB_periph_3 RBLB_periph_tap1 RBLB_periph_wire3 0.5Ohm
Rwire_RBLB_periph_4 RBLB_periph_wire3 RBLB_periph_tap2 0.5Ohm
Rwire_RBLB_periph_5 RBLB_periph_tap2 RBLB_periph_far 0.5Ohm
Cwire_RBLB_periph_0 RBLB VSS 2.4999999999999996e-17
Cwire_RBLB_periph_1 RBLB_periph_tap0 VSS 4.999999999999999e-17
Cwire_RBLB_periph_2 RBLB_periph_wire1 VSS 4.999999999999999e-17
Cwire_RBLB_periph_3 RBLB_periph_tap1 VSS 4.999999999999999e-17
Cwire_RBLB_periph_4 RBLB_periph_wire3 VSS 4.999999999999999e-17
Cwire_RBLB_periph_5 RBLB_periph_tap2 VSS 4.999999999999999e-17
Cwire_RBLB_periph_6 RBLB_periph_far VSS 2.4999999999999996e-17
Xsram_3x1_replica_column VDD VSS RBL RBLB VSS VSS RWL_tap1 sram_3x1_replica_column
XRWL VDD VSS VDD wl_en_line_far RWL WORDLINEDRIVER
Rwire_RWL_0 RWL RWL_tap0 0.5Ohm
Rwire_RWL_1 RWL_tap0 RWL_wire1 0.5Ohm
Rwire_RWL_2 RWL_wire1 RWL_tap1 0.5Ohm
Rwire_RWL_3 RWL_tap1 RWL_far 0.5Ohm
Cwire_RWL_0 RWL VSS 2.4999999999999996e-17
Cwire_RWL_1 RWL_tap0 VSS 4.999999999999999e-17
Cwire_RWL_2 RWL_wire1 VSS 4.999999999999999e-17
Cwire_RWL_3 RWL_tap1 VSS 4.999999999999999e-17
Cwire_RWL_4 RWL_far VSS 2.4999999999999996e-17
XRWL_LOAD_0 VDD VSS VDD VDD RWL_tap0 Dummy_CELL
XTIME_CONTROL VDD VSS clk csb web clk_buf clk_bar cs_bar cs we_bar we gated_clk_bar gated_clk_buf wl_en A0 A1 A_dff0 A_dff1 XREPLICA_SENSEAMP:IN_end rbl_delay rbl_delay_bar s_en w_en PRE sa_iso RWL_far XPRECHARGE_RBL:ENB_end XREPLICA_SENSEAMP:ISO_end XREPLICA_SENSEAMP:EN_end XREPLICA_WDRV_LOAD:EN_end TIME_CONTROL
MCSINIT_P cs_bar cs_init_bar VDD VDD PMOS_VTG l=5e-08 w=4.32e-06
MCSINIT_N cs cs_init VSS VSS NMOS_VTG l=5e-08 w=1.44e-06
VCSINIT cs_init VSS DC 0V PULSE(1.0V 0V 2.6199999999999997ns 0.018ns 0.018ns 899.9999999999998ns 1799.9999999999995ns)
VCSINITB cs_init_bar VSS DC 0V PULSE(0V 1.0V 2.6199999999999997ns 0.018ns 0.018ns 899.9999999999998ns 1799.9999999999995ns)
XDECODER VDD VSS A_dff0 A_dff1 DEC_WL0 DEC_WL1 DEC_WL2 DECODER_CASCADE
XWL_DRV_0 VDD VSS DEC_WL0 wl_en_line_tap0 WL0 WORDLINEDRIVER
XWL_DRV_1 VDD VSS DEC_WL1 wl_en_line_tap1 WL1 WORDLINEDRIVER
XWL_DRV_2 VDD VSS DEC_WL2 wl_en_line_tap2 WL2 WORDLINEDRIVER
XPRECHARGE_0 VDD PRE_line_tap0 BL0_periph_tap0 BLB0_periph_tap0 PRECHARGE
XPRECHARGE_1 VDD PRE_line_tap1 BL1_periph_tap0 BLB1_periph_tap0 PRECHARGE
XPRECHARGE_RBL VDD PRE_line_far RBL_periph_tap0 RBLB_periph_tap0 PRECHARGE
XREPLICA_SENSEAMP VDD VSS s_en_line_far sa_iso_line_far RBL_periph_tap2 RBLB_periph_tap2 REPLICA_SA_Q REPLICA_SA_QB SENSEAMP
XSENSEAMP_0 VDD VSS s_en_line_tap0 sa_iso_line_tap0 BL0_periph_tap2 BLB0_periph_tap2 SA_Q0 SA_QB0 SENSEAMP
XSENSEAMP_1 VDD VSS s_en_line_tap1 sa_iso_line_tap1 BL1_periph_tap2 BLB1_periph_tap2 SA_Q1 SA_QB1 SENSEAMP
XREPLICA_WDRV_LOAD VDD VSS w_en_line_far VSS RBL_periph_tap1 RBLB_periph_tap1 WRITEDRIVER
XWRITEDRIVER_0 VDD VSS w_en_line_tap0 VSS BL0_periph_tap1 BLB0_periph_tap1 WRITEDRIVER
XWRITEDRIVER_1 VDD VSS w_en_line_tap1 VSS BL1_periph_tap1 BLB1_periph_tap1 WRITEDRIVER
XD_LATCH VDD VSS SA_Q1 s_en_line_tap1 OUT OUT_B D_LATCH
VADDR_0 A0 VSS DC 0V PULSE(0V 1.0V 1.9ns 0.08999999999999998ns 0.08999999999999998ns 1.7999999999999998ns 8.999999999999998ns)
VADDR_1 A1 VSS 0V
VCLK clk VSS DC 0V PULSE(0V 1.0V 2.8ns 0.08999999999999998ns 0.08999999999999998ns 4.499999999999999ns 8.999999999999998ns)
VCSB csb VSS DC 0V PULSE(0V 1.0V 1.0ns 0.08999999999999998ns 0.08999999999999998ns 0.8999999999999999ns 8.999999999999998ns)
VWEB web VSS DC 0V PULSE(0V 1.0V 1.9ns 0.08999999999999998ns 0.08999999999999998ns 8.819999999999999ns 8.999999999999998ns)
.options TEMP = 27
.options TNOM = 27
.ic V(A_dff0)=0V V(A_dff1)=0V V(BL0)=1.0V V(BL1)=1.0V V(BLB0)=1.0V V(BLB1)=1.0V V(OUT)=1.0V V(RBL)=1.0V V(RBLB)=1.0V V(SA_Q0)=1.0V V(SA_Q1)=1.0V V(SA_QB0)=1.0V V(SA_QB1)=1.0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_0_0:Q)=0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_0_0:QB)=1.0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_0_1:Q)=0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_0_1:QB)=1.0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_0:Q)=0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_0:QB)=1.0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_1:Q)=0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_1:QB)=1.0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_2_0:Q)=0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_2_0:QB)=1.0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_2_1:Q)=0V V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_2_1:QB)=1.0V V(XTIME_CONTROL:A_reg0)=0V V(XTIME_CONTROL:A_reg1)=0V V(XTIME_CONTROL:Xdff_buf1:qint)=1.0V V(XTIME_CONTROL:Xdff_buf:qint)=1.0V V(cs_bar)=1.0V V(we)=0V V(we_bar)=1.0V
.meas TRAN TPRCH TRIG V(PRE)=0.5 FALL=1 TD=6.85e-09 TARG V(XSRAM_6T_CORE_3x2:BL1_tap1)=0.9 RISE=1 TD=6.85e-09
.meas TRAN TDECODER TRIG V(A_dff0)=0.5 RISE=1 TARG V(DEC_WL1)=0.5 RISE=1
.meas TRAN TWLDRV TRIG V(wl_en)=0.5 RISE=1 TARG V(XSRAM_6T_CORE_3x2:WL1_tap1)=0.5 RISE=1
.meas TRAN TWL WHEN V(XSRAM_6T_CORE_3x2:WL1_tap1)=0.5 RISE=1 TD=2.8e-09 TO=7.3e-09
.meas TRAN TBL WHEN V(XSENSEAMP_1:IN_end)='V(XSENSEAMP_1:INB_end)-0.25' FALL=1 TD=2.8e-09 TO=7.3e-09
.meas TRAN TSWING PARAM='TBL-TWL'
.meas TRAN TSA TRIG V(s_en)=0.5 RISE=1 TARG V(OUT)=0.5 FALL=1
.meas TRAN Ts_en TRIG V(S_EN)=0.2 RISE=1 TD=2.8000000000000003e-09 TARG V(S_EN)=0.8 RISE=1 TD=2.8000000000000003e-09
.meas TRAN TREAD_TOTAL TRIG V(WL_EN)=0.5 RISE=1 TARG V(OUT)=0.5 FALL=1
.meas TRAN TCLK_WLEN TRIG V(clk)=0.5 RISE=1 TARG V(wl_en)=0.5 RISE=1
.meas TRAN TCLK_DEC TRIG V(clk)=0.5 RISE=1 TARG V(DEC_WL1)=0.5 RISE=1
.meas TRAN TRESTORE TRIG V(clk)=0.5 FALL=1 TD=6.8500e-09 TARG V(XSRAM_6T_CORE_3x2:BL1_far)=0.900 RISE=1 TD=6.8500e-09
.meas TRAN EREAD INTEG {-V(VDD)*I(VVDD)} FROM=2.8000000000000003e-09 TO=1.18e-08
.meas TRAN PAVG PARAM={EREAD/9e-09}
.meas TRAN PSTC AVG {-V(VDD)*I(VVDD)} FROM=1.0900000000000002e-08 TO=1.1349999999999999e-08
.meas TRAN PDYN PARAM={PAVG-PSTC}
.meas TRAN VWL_PRE_FAR_0 FIND V(XSRAM_6T_CORE_3x2:WL1_far) WHEN V(PRE)=0.9 FALL=1 TD=7.3e-09 TO=1.18e-08
.meas TRAN VWL_PRE_LOCAL_0 FIND V(XSRAM_6T_CORE_3x2:WL1_tap1) WHEN V(PRE)=0.9 FALL=1 TD=7.3e-09 TO=1.18e-08
.meas TRAN VWL_PRE_PEAK_0 MAX {IF(V(PRE)<0.9,MAX(ABS(V(XSRAM_6T_CORE_3x2:WL1_far)),ABS(V(XSRAM_6T_CORE_3x2:WL1_tap1))),0)} FROM=7.3e-09 TO=1.18e-08
.meas TRAN VACCESS_ERROR_0 FIND {MAX(MAX(ABS(V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_1:Q)-0),ABS(V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_1:QB)-1)),ABS(V(OUT)-0))} AT=7.12e-09
.meas TRAN VHOLD_ERROR_0 MAX {MAX(MAX(ABS(V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_1:Q)-0),ABS(V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_1:QB)-1)),ABS(V(OUT)-0))} FROM=7.12e-09 TO=1.18e-08
.meas TRAN VPRE_ACCESS_ERROR_0 MAX {MAX(IF(V(XSRAM_6T_CORE_3x2:WL1_tap1)>0.1,ABS(V(XPRECHARGE_1:ENB_end)-1),0),IF(V(XWRITEDRIVER_1:EN_end)>0.5,ABS(V(XPRECHARGE_1:ENB_end)-1),0))} FROM=2.8e-09 TO=1.18e-08
.meas TRAN VROLE_ERROR_0 MAX {MAX(IF(V(XSENSEAMP_1:EN_end)>0.1,ABS(V(XSRAM_6T_CORE_3x2:WL1_tap1)),0),IF(V(XWRITEDRIVER_1:EN_end)>0.1,ABS(V(XSENSEAMP_1:EN_end)),0))} FROM=2.8e-09 TO=1.18e-08
.meas TRAN VISO_ERROR_0 MAX {IF(MAX(V(XSENSEAMP_1:EN_end),V(XWRITEDRIVER_1:EN_end))>0.1,ABS(V(XSENSEAMP_1:ISO_end)-1),0)} FROM=2.8e-09 TO=1.18e-08
.meas TRAN VBOUNDARY_ERROR_0 FIND {MAX(MAX(MAX(MAX(MAX(MAX(MAX(MAX(ABS(V(XSRAM_6T_CORE_3x2:WL1_tap1)),MAX(ABS(V(XWRITEDRIVER_1:EN_end)),MAX(ABS(V(XSENSEAMP_1:EN_end)),ABS(V(XSENSEAMP_1:ISO_end))))),ABS(V(XTIME_CONTROL:wordline_busy))),ABS(V(XTIME_CONTROL:iso_ready))),ABS(V(XTIME_CONTROL:access_request))),ABS(V(XTIME_CONTROL:access_settled))),ABS(V(XTIME_CONTROL:read_done))),ABS(V(rbl_delay))),ABS(V(XTIME_CONTROL:enables_off)-1))} AT=2.8e-09
.meas TRAN VRESTORE_ERROR_0 FIND {MAX(MAX(ABS(V(XSRAM_6T_CORE_3x2:BL1_far)-1),ABS(V(XSRAM_6T_CORE_3x2:BLB1_far)-1)),ABS(V(Xsram_3x1_replica_column:RBL_far)-1))} AT=1.09e-08
.PRINT TRAN FORMAT=STD PRECISION=16 V(VDD) V(VSS) V(CLK) V(CSB) V(WEB) V(A_DFF0) V(A_DFF1) V(PRE) V(PRE_line_tap1) V(XPRECHARGE_1:ENB_end) V(DEC_WL1) V(WL_EN) V(wl_en_line_tap1) V(WL1) V(XSRAM_6T_CORE_3x2:WL1_tap1) V(S_EN) V(s_en_line_tap1) V(XSENSEAMP_1:EN_end) V(SA_ISO) V(sa_iso_line_tap1) V(XSENSEAMP_1:ISO_end) V(XSRAM_6T_CORE_3x2:BL1_tap1) V(XSRAM_6T_CORE_3x2:BLB1_tap1) V(BL1_periph_tap2) V(BLB1_periph_tap2) V(XSENSEAMP_1:IN_end) V(XSENSEAMP_1:INB_end) V(BL1_periph_tap0) V(BLB1_periph_tap0) V(XPRECHARGE_1:BL_end) V(XPRECHARGE_1:BLB_end) V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_1:Q) V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_1:QB) V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_1:Q_end) V(XSRAM_6T_CORE_3x2:XSRAM_6T_CELL_1_1:QB_end) V(SA_Q1) V(SA_QB1) V(OUT) V(OUT_B) V(W_EN) V(w_en_line_tap1) V(XWRITEDRIVER_1:EN_end)
.end